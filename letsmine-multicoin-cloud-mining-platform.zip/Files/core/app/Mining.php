<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mining extends Model
{
    protected $table ="minings";
    protected $guarded = [];

}
