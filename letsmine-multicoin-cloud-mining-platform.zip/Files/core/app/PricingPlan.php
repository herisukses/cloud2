<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PricingPlan extends Model
{
    protected $table ="pricing_plans";
    protected  $guarded = [];

    public function unit()
    {
        return $this->belongsTo('App\Unit');
    }

    public function mining()
    {
        return $this->belongsTo('App\Mining','cat_id');
    }
}
