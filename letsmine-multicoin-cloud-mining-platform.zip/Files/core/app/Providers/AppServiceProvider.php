<?php

namespace App\Providers;

use App\Category;
use App\EarnRevenue;
use App\Feature;
use App\IntegrationStep;
use App\OurClient;
use App\Post;
use App\Service;
use App\Testimonial;
use View;
use App\Menu;
use App\Social;
use App\Advertisment;
use App\GeneralSettings;

use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        $data['basic'] = GeneralSettings::first();
        $data['gnl'] = GeneralSettings::first();
        $data['menus'] = Menu::all();
        $data['social'] = Social::all();
        $data['testimonials'] = Testimonial::all();
        $data['clients'] = OurClient::all();



        //blog Category
        $data['categories'] = Category::whereStatus(1)->get();
        $data['popular'] = Post::whereStatus(1)->orderBy('hit', 'DESC')->limit(5)->get();

        $data['gads_1'] = Advertisment::where('size', 1)->inRandomOrder()->first();

        view::share($data);

    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
