<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IntegrationStep extends Model
{
    protected $guarded = [];
    protected $table = "integration_steps";
}
