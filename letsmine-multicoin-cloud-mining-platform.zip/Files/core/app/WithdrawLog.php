<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WithdrawLog extends Model
{
    protected $table = 'withdraw_logs';

    protected $guarded = [];

    public function user()
    {
        return $this->belongsTo(User::class,'user_id')->withDefault();
    }

    public function method()
    {
        return $this->belongsTo('App\WithdrawMethod')->withDefault();
    }

    public function wallet()
    {
        return $this->belongsTo('App\Wallet','wallet_id');
    }

}
