<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlanLog extends Model
{
    protected $table = "plan_logs";

    protected $guarded = [];

    public function pricingPlan()
    {
        return $this->belongsTo('App\PricingPlan','pricing_plan_id');
    }

}
