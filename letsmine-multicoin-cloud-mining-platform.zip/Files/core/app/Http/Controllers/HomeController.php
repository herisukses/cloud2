<?php

namespace App\Http\Controllers;

use App\Match;
use App\PlanLog;
use App\PricingPlan;
use App\Trx;
use App\Wallet;
use App\WithdrawLog;
use App\WithdrawMethod;
use Illuminate\Http\Request;
use App\User;
use Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Str;
use Session;
use Image;
use App\Gateway;
use App\GeneralSettings;
use App\Deposit;


use App\BetInvest;
use App\BetOption;
use App\BetQuestion;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

        $this->middleware('auth');
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['page_title'] = "Dashboard";
        $data['wallets'] = Wallet::where('user_id', Auth::user()->id)->get();
        $data['deposit'] = Deposit::where('user_id', Auth::user()->id)->whereStatus(1)->sum('amount');
        $data['package'] = PricingPlan::whereStatus(1)->count();
        $data['gateway'] = Gateway::whereStatus(1)->count();
        $data['withdrawMethod'] = WithdrawMethod::whereStatus(1)->count();
        $data['pur'] = PlanLog::where('user_id', Auth::id())->whereStatus(1)->count();
        return view('user.index', $data);
    }


    public function authCheck()
    {
        if (Auth()->user()->status == '1' && Auth()->user()->email_verify == '1' && Auth()->user()->sms_verify == '1') {
            return redirect()->route('home');
        } else {
            $data['page_title'] = "Authorization";
            return view('user.authorization', $data);
        }
    }

    public function sendVcode(Request $request)
    {
        $user = User::find(Auth::user()->id);

        if (Carbon::parse($user->phone_time)->addMinutes(1) > Carbon::now()) {
            $time = Carbon::parse($user->phone_time)->addMinutes(1);
            $delay = $time->diffInSeconds(Carbon::now());
            $delay = gmdate('i:s', $delay);
            session()->flash('alert', 'You can resend Verification Code after ' . $delay . ' minutes');
        } else {
            $code = strtoupper(Str::random(6));
            $user->phone_time = Carbon::now();
            $user->sms_code = $code;
            $user->save();
            send_sms($user->phone, 'Your Verification Code is ' . $code);

            session()->flash('success', 'Verification Code Send successfully');
        }
        return back();
    }

    public function smsVerify(Request $request)
    {
        $user = User::find(Auth::user()->id);
        if ($user->sms_code == $request->sms_code) {
            $user->phone_verify = 1;
            $user->save();
            session()->flash('success', 'Your Profile has been verfied successfully');
            return redirect()->route('home');
        } else {
            session()->flash('alert', 'Verification Code Did not matched');
        }
        return back();
    }

    public function sendEmailVcode(Request $request)
    {
        $user = User::find(Auth::user()->id);

        if (Carbon::parse($user->email_time)->addMinutes(1) > Carbon::now()) {
            $time = Carbon::parse($user->email_time)->addMinutes(1);
            $delay = $time->diffInSeconds(Carbon::now());
            $delay = gmdate('i:s', $delay);
            session()->flash('alert', 'You can resend Verification Code after ' . $delay . ' minutes');
        } else {
            $code = strtoupper(Str::random(6));
            $user->email_time = Carbon::now();
            $user->verification_code = $code;
            $user->save();
            send_email($user->email, $user->username, 'Verificatin Code', 'Your Verification Code is ' . $code);
            session()->flash('success', 'Verification Code Send successfully');
        }
        return back();
    }

    public function postEmailVerify(Request $request)
    {

        $user = User::find(Auth::user()->id);
        if ($user->verification_code == $request->email_code) {
            $user->email_verify = 1;
            $user->save();
            session()->flash('success', 'Your Profile has been verfied successfully');
            return redirect()->route('home');
        } else {
            session()->flash('alert', 'Verification Code Did not matched');
        }
        return back();
    }


    public function editProfile()
    {
        $data['page_title'] = "Edit Profile";
        $data['user'] = User::findOrFail(Auth::user()->id);
        return view('user.edit-profile', $data);
    }

    public function submitProfile(Request $request)
    {
        $user = User::findOrFail(Auth::user()->id);
        $request->validate([
            'name' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'zip_code' => 'required|string|max:255',
            'country' => 'required|string|max:255',
            'address' => 'required|string|max:255',
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'phone' => 'required|string|min:10|unique:users,phone,' . $user->id,
//            'username' => 'required|min:5||regex:/^\S*$/u|unique:users,username,' . $user->id,
            'image' => 'mimes:png,jpg,jpeg'
        ]);
        $in = Input::except('_method', '_token');
        $in['reference'] = $request->username;
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '_' . $request->username . '.jpg';
            $location = 'assets/images/user/' . $filename;
            $in['image'] = $filename;
            if ($user->image != 'user-default.png') {
                $path = './assets/images/user/';
                $link = $path . $user->image;
                if (file_exists($link)) {
                    @unlink($link);
                }
            }
            Image::make($image)->resize(800, 800)->save($location);
        }
        $user->fill($in)->save();
        $notification = array('message' => 'Profile Updated Successfully.', 'alert-type' => 'success');
        return back()->with($notification);

    }

    public function changePassword()
    {
        $data['page_title'] = "Change Password";
        return view('user.change-password', $data);
    }

    public function submitPassword(Request $request)
    {
        $this->validate($request, [
            'current_password' => 'required',
            'password' => 'required|min:5|confirmed'
        ]);
        try {

            $c_password = Auth::user()->password;
            $c_id = Auth::user()->id;
            $user = User::findOrFail($c_id);
            if (Hash::check($request->current_password, $c_password)) {

                $password = Hash::make($request->password);
                $user->password = $password;
                $user->save();

                $notification = array('message' => 'Password Changes Successfully.', 'alert-type' => 'success');
                return back()->with($notification);
            } else {
                $notification = array('message' => 'Current Password Not Match', 'alert-type' => 'warning');
                return back()->with($notification);
            }

        } catch (\PDOException $e) {
            $notification = array('message' => $e->getMessage(), 'alert-type' => 'warning');
            return back()->with($notification);
        }
    }

    public function deposit()
    {
        $data['page_title'] = "Select Payment Gateways";
        $data['gates'] = Gateway::whereStatus(1)->get();
        return view('user.deposit', $data);
    }

    public function depositDataInsert(Request $request)
    {
        $this->validate($request,
            [
                'amount' => 'required|numeric|min:1',
                'gateway' => 'required',
            ]);

        if ($request->amount <= 0) {
            return back()->with('alert', 'Invalid Amount');
        } else {
            $gate = Gateway::findOrFail($request->gateway);

            if (isset($gate)) {
                if ($gate->minamo <= $request->amount && $gate->maxamo >= $request->amount) {
                    $charge = $gate->fixed_charge + ($request->amount * $gate->percent_charge / 100);
                    $usdamo = ($request->amount + $charge) / $gate->rate;


                    $depo['user_id'] = Auth::id();
                    $depo['gateway_id'] = $gate->id;
                    $depo['amount'] = $request->amount;
                    $depo['charge'] = $charge;
                    $depo['usd'] = round($usdamo, 2);
                    $depo['btc_amo'] = 0;
                    $depo['btc_wallet'] = "";
                    $depo['trx'] = str_random(16);
                    $depo['try'] = 0;
                    $depo['status'] = 0;
                    Deposit::create($depo);

                    Session::put('Track', $depo['trx']);

                    return redirect()->route('user.deposit.preview');

                } else {
                    return back()->with('alert', 'Please Follow Deposit Limit');
                }
            } else {
                return back()->with('alert', 'Please Select Deposit gateway');
            }
        }

    }

    public function depositPreview()
    {
        $track = Session::get('Track');
        $data = Deposit::where('status', 0)->where('trx', $track)->first();
        $page_title = "Deposit Preview";
        return view('user.payment.preview', compact('data', 'page_title'));
    }


    public function UserPurchasePlan(Request $request)
    {
        $this->validate($request,
            [
                'totalPlan' => 'required|integer|min:1',
            ],[
                'totalPlan.required' => 'Plan purchase quantity must be needed ! ',
                'totalPlan.integer' => 'Plan purchase quantity must be integer value '
            ]
        );

        $plan = PricingPlan::find($request->id);

        if ($plan->minimum <= $request->totalPlan && $plan->maximum >= $request->totalPlan) {
            $user = User::find($request->user_id);
            $totalPrice = $request->rate * $request->totalPlan;
            if ($user->balance > $totalPrice) {

                $user->balance -= $totalPrice;
//                $user->save();

                $data['remainBalance'] = $user->balance;
                $data['totalPlan'] = $request->totalPlan;
                $data['totalPrice'] = $totalPrice;
                $data['user'] = $user;
                $data['plan'] = $plan;


                $data['totalPlan'] = $request->totalPlan;
                $data['user_id'] = $request->user_id;
                $data['rate'] = $request->rate;
                $data['pricing_plan_id'] = $request->id;
                $data['mining_id'] = $request->mining_id;

                $data['page_title'] = 'Purchase  Preview';
                return view('user.purchase-preview', $data);

            } else {
                return back()->with('alert', 'Insufficient Balance');
            }
        } else {
            return back()->with('alert', 'Please follow purchase Plan Limitation ');
        }

    }


    public function confirmPurchase(Request $request)
    {
        $basic = GeneralSettings::first();

        $plan = PricingPlan::find($request->pricing_plan_id);
        $user = User::find($request->user_id);

        if ($user->balance > ($request->rate * $request->total_plan)) {
            $data['user_id'] = $request->user_id;
            $data['pricing_plan_id'] = $request->pricing_plan_id;
            $data['mining_id'] = $request->mining_id;
            $data['qty'] = $request->total_plan;
            $data['status'] = 1;
            $carbon = new Carbon();
            if ($plan->duration == "day") {
                $day = $plan->period * 1;
                $data['end_time'] = $carbon->addDays($day);
            } elseif ($plan->duration == "month") {
                $month = $plan->period * 30;
                $data['end_time'] = $carbon->addDays($month);
            } elseif ($plan->duration == "year") {
                $year = $plan->period * 365;
                $data['end_time'] = $carbon->addDays($year);
            }

                PlanLog::create($data);

            $checkWallet = Wallet::where('user_id', $user->id)->where('mining_id', $plan->cat_id)->get();

            if (count($checkWallet) == 0) {
                $wallet['user_id'] = $user->id;
                $wallet['mining_id'] = $plan->cat_id;
                Wallet::create($wallet);
            }

            $user->balance -= $request->rate * $request->total_plan;
            $user->save();

            $trx = Trx::create([
                'user_id' => $user->id,
                'amount' => number_format(($plan->rate * $request->total_plan), $basic->decimal),
                'main_amo' => number_format($user->balance, $basic->decimal),
                'charge' => 0,
                'type' => '-',
                'title' => 'you are total ' . $request->total_plan . ' item Purchase ' . $plan->title,
                'trx' => strtoupper(str_random(20))
            ]);

            return redirect()->route('myPlan.history')->with('success', 'Successfully Purchase  Plan');

        }
    }


    public function activity()
    {
        $user = Auth::user();
        $data['invests'] = Trx::whereUser_id($user->id)->latest()->paginate(10);
        $data['page_title'] = "Transaction Log";
        return view('user.trx', $data);
    }

    public function depositLog()
    {
        $user = Auth::user();
        $data['invests'] = Deposit::whereUser_id($user->id)->whereStatus(1)->latest()->paginate(20);
        $data['page_title'] = "Deposit Log";
        return view('user.deposit-log', $data);
    }

    public function withdrawLog()
    {
        $user = Auth::user();
        $data['invests'] = WithdrawLog::whereUser_id($user->id)->where('status', '!=', 0)->latest()->paginate(20);
        $data['page_title'] = "Withdraw Log";
        return view('user.withdraw-log', $data);
    }

    public function withdrawMoney()
    {
        $data['withdrawMethod'] = Wallet::where('user_id', Auth::user()->id)->get();
        $data['page_title'] = "Withdraw Fund";
        return view('user.withdraw-money', $data);
    }

    public function requestPreview(Request $request)
    {
        $this->validate($request, [
            'amount' => 'required|numeric|min:0'
        ]);

        $basic = GeneralSettings::first();
        $bal = User::findOrFail(Auth::user()->id);

        $method = Wallet::findOrFail($request->wallet_id);

        $ch = round(($request->amount * $basic->withdraw_charge) / 100, $basic->decimal);
        $reAmo = $request->amount + $ch;


        if ($reAmo > $method->balance) {
            return back()->with('alert', 'Your Request Amount is Larger Then Your Current Balance.');
        } else {
            $tr = strtoupper(str_random(20));
            $w['amount'] = $request->amount;
            $w['wallet_id'] = $request->wallet_id;
            $w['charge'] = $ch;
            $w['transaction_id'] = $tr;
            $w['net_amount'] = $reAmo;
            $w['user_id'] = Auth::user()->id;
            $trr = WithdrawLog::create($w);
            $data['withdraw'] = $trr;
            Session::put('wtrx', $trr->transaction_id);

            $data['method'] = $method;
            $data['balance'] = $method;

            $data['page_title'] = $method->mining->coin_code . " withdraw Preview";
            return view('user.withdraw-preview', $data);
        }
    }


    public function requestSubmit(Request $request)
    {

        $basic = GeneralSettings::first();
        $this->validate($request, [
            'withdraw_id' => 'required',
            'send_details' => 'required',
        ],
            [
                'send_details.required' => 'Enter Your Account Information',
            ]
        );

        if($request->send_details)
        {
            $ww = WithdrawLog::findOrFail($request->withdraw_id);
            $ww->send_details = $request->send_details;
            $ww->message = $request->message;
            $ww->status = 1;
            $ww->save();

            $user = Wallet::where('user_id', Auth::user()->id)->where('id', $ww->wallet_id)->first();
            $user->balance = $user->balance - $ww->net_amount;
            $user->save();

            $trx = Trx::create([
                'user_id' => $user->user_id,
                'amount' => $ww->amount,
                'main_amo' => $user->balance,
                'charge' => $ww->charge,
                'mining_id' => $user->mining_id,
                'type' => '-',
                'title' => 'Withdraw Request Via ' . $user->mining->coin_code,
                'trx' => $ww->transaction_id
            ]);
            $text = 'Withdraw Request Via ' . $ww->amount . ' ' . $user->mining->coin_code . "<br>" . " Your current balance " . $user->balance . " " . $user->mining->name;
            notify($user->user, 'Withdraw Via ' . $user->mining->coin_code, $text);
            return redirect()->route('withdraw.money')->with('success', 'Withdraw request Successfully Submitted. Wait For Confirmation.');
        }

    }


    public function walletSettings()
    {
        $data['page_title'] = "Wallet Settings";
        $data['wallets'] = Wallet::where('user_id', Auth::user()->id)->get();
        return view('user.wallet', $data);
    }

    public function walletSettingsUpdate(Request $request)
    {
        foreach ($request->id as $key => $value) {
            $value5413 = Wallet::find($value);
            $value5413->wallet_acc = $request->wallet_acc[$key];
            $value5413->save();
        }
        return back()->with('success', 'Wallet Account Successfully Updated.');
    }

    public function myPlan()
    {
        $data['myPlan'] = PlanLog::whereUser_id(Auth::user()->id)->latest()->paginate(20);
        $data['page_title'] = "PURCHASE HISTORY";
        return view('user.plan-log', $data);
    }


}
