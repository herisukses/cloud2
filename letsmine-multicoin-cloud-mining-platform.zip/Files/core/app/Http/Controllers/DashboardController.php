<?php

namespace App\Http\Controllers;

use App\Subscriber;
use Illuminate\Http\Request;
use Auth;
use App\GeneralSettings;
use App\User;
use App\Mining;
use App\PricingPlan;
use App\Unit;
use Carbon\Carbon;
use Illuminate\Support\Facades\Input;

class DashboardController extends Controller
{
    public function __construct()
    {

    }

    public function category()
    {
        $data['page_title'] = 'All Coins';
        $data['events'] = Mining::latest()->get();
        return view('admin.pages.mining', $data);
    }

    public function UpdateCategory(Request $request)
    {
        $macCount = Mining::where('name', $request->name)->where('id', '!=', $request->id)->count();
        if ($macCount > 0) {
            return back()->with('alert', 'This one Already Exist');
        }
        if ($request->id == 0) {
            $data['name'] = $request->name;
            $data['coin_code'] = $request->coin_code;
            $data['status'] = $request->status;
            $res = Mining::create($data);
            if ($res) {
                return back()->with('success', 'Saved Successfully!');
            } else {
                return back()->with('alert', 'Problem With Adding New Category');
            }

        } else {
            $mac = Mining::findOrFail($request->id);
            $mac['name'] = $request->name;
            $mac['coin_code'] = $request->coin_code;
            $mac['status'] = $request->status;
            $res = $mac->save();

            if ($res) {
                return back()->with('success', ' Updated Successfully!');
            } else {
                return back()->with('alert', 'Problem With Updating Category');
            }
        }
    }

    public function unit()
    {
        $data['page_title'] = 'Manage Unit';
        $data['events'] = Unit::all();
        return view('admin.pages.unit', $data);
    }

    public function UpdateUnit(Request $request)
    {
        $macCount = Unit::where('name', $request->name)->where('id', '!=', $request->id)->count();
        if ($macCount > 0) {
            return back()->with('alert', 'This one Already Exist');
        }
        if ($request->id == 0) {
            $data['name'] = $request->name;
            $data['code'] = $request->code;
            $data['status'] = $request->status;
            $res = Unit::create($data);
            if ($res) {
                return back()->with('success', 'Saved Successfully!');
            } else {
                return back()->with('alert', 'Problem With Adding New Unit');
            }

        } else {
            $mac = Unit::findOrFail($request->id);
            $mac['name'] = $request->name;
            $mac['code'] = $request->code;
            $mac['status'] = $request->status;
            $res = $mac->save();

            if ($res) {
                return back()->with('success', ' Updated Successfully!');
            } else {
                return back()->with('alert', 'Problem With Updating Unit');
            }
        }
    }


    public function createPlan()
    {
        $data['page_title'] = 'Add New Plan';
        $data['minner'] = Mining::whereStatus(1)->get();
        $data['units'] = Unit::whereStatus(1)->get();
        return view('admin.pages.create-plan', $data);
    }

    public function storePlan(Request $request)
    {

        $request->validate([
            'title' => 'required',
            'cat_id' => 'required',
            'rate' => 'required|numeric',
            'unit_id' => 'required',
            'period' => 'required|numeric',
            'minimum' => 'required|numeric|min:1',
            'maximum' => 'required|numeric|min:1',
            'return_amount' => 'required',
            'details' => 'required',
            'details' => 'required',
            'electricity_charge'=>'required|numeric|min:0',
        ],
            [
                'title.required' => 'Plan Title Must not be empty',
                'cat_id.required' => 'Coin Must be selected',
                'rate.required' => 'Plan rate must not be empty',
                'rate.numeric' => 'Plan rate must be numeric value',
                'period.numeric' => 'Plan Duration must be numeric value',
                'electricity_charge.required'=>'Enter Maintenance Fee ',
            ]
        );
        $basic = GeneralSettings::first();
        $in = Input::except('_token','details');
        $in['return_amount'] = round($request->return_amount, $basic->decimal);
        $in['rate'] = round($request->rate, $basic->decimal);
        $in['details'] = json_encode($request->details);

        $in['status'] = $request->status == 'on' ? '1' : '0';

        $res = PricingPlan::create($in);

        if ($res) {
            return back()->with('success', 'Saved Successfully!');
        } else {
            return back()->with('alert', 'Problem With Adding New Unit');
        }
    }

    public function plans()
    {
        $data['page_title'] = 'All Plan';
        $data['plans'] = PricingPlan::latest()->paginate(20);
        return view('admin.pages.plans', $data);
    }


    public function editPlan($id)
    {
        $data['page_title'] = 'Edit Plan';
        $data['plan'] = PricingPlan::find($id);
        $data['minner'] = Mining::whereStatus(1)->get();
        $data['units'] = Unit::whereStatus(1)->get();
        return view('admin.pages.edit-plan', $data);
    }

    public function updatePlan(Request $request)
    {
        $basic = GeneralSettings::first();


        $data = PricingPlan::find($request->id);
        $request->validate([
            'title' => 'required',
            'cat_id' => 'required',
            'rate' => 'required|numeric',
            'unit_id' => 'required',
            'period' => 'required|numeric',
            'minimum' => 'required|numeric|min:1',
            'maximum' => 'required|numeric|min:1',
            'return_amount' => 'required',
            'details' => 'required',
            'electricity_charge' => 'required|numeric|min:0',
        ],
            [
                'title.required' => 'Plan Title Must not be empty',
                'cat_id.required' => 'Coin Must be selected',
                'rate.required' => 'Plan rate must not be empty',
                'rate.numeric' => 'Plan rate must be numeric value',
                'period.numeric' => 'Plan Duration must be numeric value',
                'electricity_charge.required'=>'Enter  Maintenance Fee',
            ]
        );


        $in = Input::except('_token','details');
        $in['return_amount'] = round($request->return_amount, $basic->decimal);
        $in['rate'] = round($request->rate, $basic->decimal);
        $in['details'] = json_encode($request->details);
        $in['status'] = $request->status == 'on' ? '1' : '0';

        $res = $data->fill($in)->save();

        if ($res) {
            return back()->with('success', 'Updated Successfully!');
        } else {
            return back()->with('alert', 'Problem With Updating Plan');
        }

        return $data;
    }

    public function manageSubscribers()
    {
        $data['page_title'] = 'Subscribers';
        $data['events'] = Subscriber::latest()->paginate(30);
        return view('admin.pages.subscriber', $data);
    }

    public function updateSubscriber(Request $request)
    {
        $mac = Subscriber::findOrFail($request->id);
        $mac['status'] = $request->status;
        $res = $mac->save();

        if ($res) {
            return back()->with('success', ' Updated Successfully!');
        } else {
            return back()->with('alert', 'Problem With Updating Category');
        }
    }

    public function sendMail()
    {
        $data['page_title'] = 'Mail to Subscribers';
        return view('admin.pages.subscriber-email', $data);
    }

    public function sendMailsubscriber(Request $request)
    {
        $this->validate($request,
            [
                'subject' => 'required',
                'emailMessage' => 'required'
            ]);
        $subscriber = Subscriber::whereStatus(1)->get();
        foreach ($subscriber as $data) {
            $to =  $data->email;
            $name = substr($data->email, 0, strpos($data->email, "@"));
            $subject = $request->subject;
            $message = $request->emailMessage;
            send_email($to, $name, $subject, $message);
        }
        $notification = array('message' => 'Mail Sent Successfully!', 'alert-type' => 'success');
        return back()->with($notification);
    }


}
