<?php

namespace App\Http\Controllers;

use App\EarnRevenue;
use App\Feature;
use App\GeneralSettings;
use App\IntegrationStep;
use App\OurClient;
use App\Service;
use App\Team;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use File;
use Image;

class TemplateSetupController extends Controller
{
    public function section1()
    {
        $data['page_title'] = "Section 1";
        return view('templateSetup.section-1', $data);
    }
    public function updSection1(Request $request)
    {
        $this->validate($request,[
            'header_vector' => 'image|mimes:png',
        ]);
        if($request->hasFile('header_vector')){
            $image = $request->file('header_vector');
            $filename = 'header-vector.png';
            $location = 'assets/images/logo/' . $filename;
            Image::make($image)->save($location);
        }

        $basic = GeneralSettings::first();
        $in = Input::except('_method','_token','header_vector');
        $basic->fill($in)->save();
        $notification = array('message' => ' Updated Successfully.', 'alert-type' => 'success');
        return back()->with($notification);
    }

    public function index()
    {
        $data['page_title'] = "Section 3";
        $data['howItworks'] = Service::all();
        return view('templateSetup.howItWork', $data);
    }

    public function editHowItWork($id)
    {
        $data['page_title'] ="Section 3";
        $data['post'] = Service::findOrFail($id);
        return view('templateSetup.edit-howitwork', $data);
    }

    public function updateHowItWork(Request $request, $id)
    {
        $request->validate([
            'title' => 'required',
            'details' => 'required',
        ],
            [
                'title.required' => ' Title Must not be empty',
                'icon.required' => 'Font Awesome Icon  Must not be empty',
                'details.required' => 'Details  must not be empty',
            ]
        );
        $data = Service::findOrFail($id);
        $in = input::except('_token');
        $data->fill($in)->save();
        $notification = array('message' => 'Updated Successfully.', 'alert-type' => 'success');
        return back()->with($notification);
    }


    public function wayToEarn()
    {
        $data['page_title'] = " Section 1 ";
        $data['earnRevenue'] = EarnRevenue::all();
        return view('templateSetup.wayToEarn', $data);
    }

    public function createWayToEarn()
    {
        $data['page_title'] = " Add New";
        return view('templateSetup.create-wayToEarn', $data);
    }

    public function storeWayToEarn(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'image' => 'required|mimes:png,PNG| max:1000',
        ],
            [
                'title.required' => ' Title Must not be empty',
                'details.required' => 'Details  must not be empty',
            ]
        );
        $in = input::except('_token');
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = 'earnRevenue_' . time() . '.png';
            $location = 'assets/images/' . $filename;
            Image::make($image)->resize(80, 90)->save($location);
            $in['image'] = $filename;
        }
        EarnRevenue::create($in);
        $notification = array('message' => 'Saved Successfully.', 'alert-type' => 'success');
        return back()->with($notification);
    }
    public function editWayToEarn($id)
    {
        $data['page_title'] = " Edit";
        $data['post'] = EarnRevenue::findOrFail($id);
        return view('templateSetup.edit-wayToEarn', $data);
    }

    public function updateWayToEarn(Request $request, $id)
    {
        $request->validate([
            'title' => 'required',
            'image' => 'nullable|mimes:png,PNG| max:1000',
        ],
            [
                'title.required' => ' Title Must not be empty',
                'details.required' => 'Details  must not be empty',
            ]
        );
        $data = EarnRevenue::findOrFail($id);
        $in = input::except('_token');
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = 'earnRevenue_' . time() . '.png';
            $location = 'assets/images/' . $filename;
            Image::make($image)->resize(80, 90)->save($location);
            $path = './assets/images/';
            File::delete($path . $data->image);
            $in['image'] = $filename;
        }

        $data->fill($in)->save();
        $notification = array('message' => 'Updated Successfully.', 'alert-type' => 'success');
        return back()->with($notification);
    }

    public function deleteWayToEarn(Request $request)
    {
        $data = EarnRevenue::find($request->id);
        $path = './assets/images/';
        File::delete($path . $data->image);
        $data->delete();
        $notification = array('message' => 'Deleted Successfully.', 'alert-type' => 'success');
        return back()->with($notification);

    }

    public function features()
    {
        $data['page_title'] = " features Section";
        $data['features'] = Feature::all();
        return view('templateSetup.features', $data);
    }

    public function editFeatures($id)
    {
        $data['page_title'] = " features Section";
        $data['post'] = Feature::findOrFail($id);
        return view('templateSetup.edit-features', $data);
    }

    public function updateFeatures(Request $request, $id)
    {
        $request->validate([
            'title' => 'required',
            'details' => 'required',
            'icon' => 'required',
        ],
            [
                'title.required' => ' Title Must not be empty',
                'icon.required' => 'Font Awesome Icon  Must not be empty',
                'details.required' => 'Details  must not be empty',
            ]
        );
        $data = Feature::findOrFail($id);
        $in = input::except('_token');
        $data->fill($in)->save();
        $notification = array('message' => 'Updated Successfully.', 'alert-type' => 'success');
        return back()->with($notification);
    }






    public function manageGetStarted()
    {
        $data['page_title'] = "Manage Section 6  ";
        return view('templateSetup.get-started', $data);
    }

    public function updateGetStarted(Request $request, $id)
    {
        $basic = GeneralSettings::find($id);
        $in = Input::except('_method', '_token');
        $basic->fill($in)->save();
        $notification = array('message' => 'Updated Successfully.', 'alert-type' => 'success');
        return back()->with($notification);
    }

    public function integration()
    {
        $data['integrationStep1'] = IntegrationStep::first();;
        $data['integrationStep2'] = IntegrationStep::take(3)->skip(1)->get();
        $data['page_title'] = "Manage Section 5 ";
        return view('templateSetup.integration', $data);
    }

    public function updateOneIntegration(Request $request, $id)
    {
        $data = IntegrationStep::find($request->id);
        $request->validate([
            'val1' => 'required',
            'val2' => 'required',
            'image' => 'nullable | mimes:png,PNG | max:1000'
        ],
            [
                'val1.required' => ' Title Must not be empty',
                'val2.required' => 'Details Must be empty',
            ]
        );
        $data = IntegrationStep::find($id);
        $in = input::except('_token');
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = 'integration_steps_' . time() . '.png';
            $location = 'assets/images/' . $filename;
            Image::make($image)->resize(65, 75)->save($location);
            $path = './assets/images/';
            File::delete($path . $data->image);
            $in['image'] = $filename;
        }
        $data->fill($in)->save();

        $notification = array('message' => 'Updated Successfully.', 'alert-type' => 'success');
        return back()->with($notification);
    }

    public function reward()
    {
        $data['page_title'] = "Manage Reward Section";
        return view('templateSetup.reward', $data);
    }

    public function updateReward(Request $request, $id)
    {
        $request->validate([
            'reward_title' => 'required',
            'reward_image' => 'nullable | mimes:png,PNG | max:1000'
        ],
            [
                'reward_title.required' => ' Title Must not be empty',
                'reward_image.mimes' => 'Image Only allowed png types',
            ]
        );
        $data = GeneralSettings::find($id);

        $in = input::except('_token');
        if ($request->hasFile('reward_image')) {
            $image = $request->file('reward_image');
            $filename = 'reward_image_' . time() . '.png';
            $location = 'assets/images/' . $filename;
            Image::make($image)->save($location);
            $path = './assets/images/';
            File::delete($path . $data->reward_image);
            $in['reward_image'] = $filename;
        }
        $data->fill($in)->save();

        $notify = array('message' => 'Updated Successfully.', 'alert-type' => 'success');
        return back()->with($notify);
    }

    public function ourClient()
    {
        $data['page_title'] = "Our Client ";
        $data['ourClient'] = OurClient::all();
        return view('templateSetup.ourclient', $data);
    }

    public function storeClient(Request $request)
    {
        $request->validate([
            'link' => 'required',
            'image' => 'required | mimes:png,PNG | max:1000'
        ],
            [
                'link.required' => ' Website address must not be empty',
                'image.mimes' => 'Image Only allowed png types',
            ]
        );

        $in = input::except('_token');
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = 'client_image_' . time() . '.png';
            $location = 'assets/images/our-client/' . $filename;
            Image::make($image)->resize(176,58)->save($location);
            $in['image'] = $filename;
        }
        OurClient::create($in);

        $notify = array('message' => 'Updated Successfully.', 'alert-type' => 'success');
        return back()->with($notify);
    }

    public function deleteClient(Request $request)
    {
        $data = OurClient::find($request->id);
        $path = './assets/images/our-client/';
        File::delete($path . $data->image);
        $data->delete();
        $notification = array('message' => 'Deleted Successfully.', 'alert-type' => 'success');
        return back()->with($notification);

    }



    public function ourTeam()
    {
        $data['page_title'] = "Our Team";
        $data['teams'] = Team::all();
        return view('templateSetup.ourTeam', $data);
    }

    public function createOurTeam()
    {
        $data['page_title'] = " Add New";
        return view('templateSetup.create-team', $data);
    }

    public function storeOurTeam(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'designation' => 'required',
            'image' => 'required|mimes:jpg,jpeg,png| max:1000',
        ],
            [
                'name.required' => ' name Must not be empty',
                'designation.required' => 'Designation  must not be empty',
            ]
        );
        $in = input::except('_token');
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = 'team_' . time() . '.jpg';
            $location = 'assets/images/our-team/' . $filename;
            Image::make($image)->save($location);
            $in['image'] = $filename;
        }
        Team::create($in);
        $notification = array('message' => 'Saved Successfully.', 'alert-type' => 'success');
        return back()->with($notification);
    }

    public function editOurTeam($id)
    {
        $data['page_title'] = " Edit";
        $data['post'] = Team::findOrFail($id);
        return view('templateSetup.edit-team', $data);
    }

    public function updateOurTeam(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
            'designation' => 'required',
            'image' => 'mimes:jpg,jpeg,png| max:1000',
        ],
            [
                'name.required' => ' name Must not be empty',
                'designation.required' => 'Designation  must not be empty',
            ]
        );

        $data = Team::findOrFail($id);
        $in = input::except('_token');
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = 'team_' . time() . '.jpg';
            $location = 'assets/images/our-team/' . $filename;
            Image::make($image)->save($location);
            $path = './assets/images/our-team/';
            File::delete($path . $data->image);
            $in['image'] = $filename;
        }

        $data->fill($in)->save();
        $notification = array('message' => 'Updated Successfully.', 'alert-type' => 'success');
        return back()->with($notification);
    }

    public function deleteOurTeam(Request $request)
    {
        $data = Team::find($request->id);
        $path = './assets/images/our-team/';
        File::delete($path . $data->image);
        $data->delete();
        $notification = array('message' => 'Deleted Successfully.', 'alert-type' => 'success');
        return back()->with($notification);

    }

}
