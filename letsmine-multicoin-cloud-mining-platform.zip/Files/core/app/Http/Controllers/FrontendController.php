<?php

namespace App\Http\Controllers;

use App\Category;
use App\Deposit;
use App\EarnRevenue;
use App\Feature;
use App\Gateway;
use App\GeneralSettings;
use App\IntegrationStep;
use App\Mining;
use App\PlanLog;
use App\Post;
use App\PricingPlan;
use App\Service;
use App\Subscriber;
use App\Team;
use App\Trx;
use App\User;
use App\Wallet;
use App\WithdrawLog;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Auth;
use App\Menu;
use App\Faq;
use App\Advertisment;

class FrontendController extends Controller
{

    public function __construct()
    {

    }

    public function index()
    {
        $data['page_title'] = "Home";
        $data['howItWork'] = Service::all();
        $take = 6;
        $data['features'] = Feature::take($take)->get();
        $data['earnRevenues'] = EarnRevenue::all();
        $data['gateway'] = Gateway::whereStatus(1)->take(10)->get();
        $data['post'] = Post::latest()->take(3)->get();

        $data['integrationStep1'] = IntegrationStep::first();;
        $data['integrationStep2'] = IntegrationStep::take(3)->skip(1)->get();

        $data['miners'] = Mining::whereStatus(1)->get();
        $data['team'] = Team::all();
        $data['plans'] = PricingPlan::whereStatus(1)->get();
        $data['deposit_pranto'] = Deposit::whereStatus(1)->latest()->take(8)->get();
        $data['withdraw_pranto'] = WithdrawLog::whereStatus(1)->latest()->take(8)->get();
        return view('front.index', $data);
    }

    public function menu($slug)
    {
        $menu = $data['menu'] = Menu::whereSlug($slug)->first();
        $data['page_title'] = "$menu->name";
        return view('layouts.menu', $data);
    }

    public function about()
    {
        $data['page_title'] = "About Us";
        $data['integrationStep1'] = IntegrationStep::first();
        $data['earnRevenues'] = EarnRevenue::all();
        $take = 3;
        $data['features'] = Feature::take($take)->get();
        $data['features2'] = Feature::take($take)->skip(3)->get();
        $data['teams'] = Team::latest()->get();
        return view('layouts.about', $data);
    }

    public function faqs()
    {
        $data['faqs'] = Faq::all();
        $data['page_title'] = "Faqs";
        return view('layouts.faqs', $data);
    }


    public function contactUs()
    {
        $data['page_title'] = "Contact Us";
        return view('layouts.contact', $data);
    }

    public function contactSubmit(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'message' => 'required'
        ]);
        $subject = "Contact Us";

        send_contact($request->email, $request->name, $subject,$request->message);
        $notification = array('message' => 'Contact Message Send.', 'alert-type' => 'success');
        return back()->with($notification);
    }

    public function clickadd($id)
    {

        $add = Advertisment::findOrFail($id);
        $data = array();
        $data['views'] = $add->views + 1;
        Advertisment::whereId($id)->update($data);
        $go = $add->link;
        return redirect($go);
    }

    public function blog()
    {
        $data['page_title'] = "Blog Feed";
        $data['posts'] = Post::latest()->paginate(3);
        return view('front.blog', $data);
    }

    public function details($id)
    {
        $post = $data['post'] = Post::find($id);
        $post->hit += 1;
        $post->save();
        $data['page_title'] = $data['post']->title;
        return view('front.details', $data);
    }

    public function categoryByBlog($id)
    {
        $cat = Category::find($id);
        $data['page_title'] = "$cat->name";
        $data['posts'] = Post::where('cat_id', $id)->latest()->paginate(3);
        return view('front.category-blog', $data);
    }

    public function pricing()
    {
        $data['page_title'] = "Start Mining Today!";
        $data['mining'] = Mining::whereStatus(1)->get();
        $data['plans'] = PricingPlan::whereStatus(1)->get();

        if(Auth::user())
        {
            return view('front.user-pricing', $data);
        }
        return view('front.pricing', $data);
    }

    public function subscribe(Request $request)
    {
		 $request->validate([
            'email' => 'required|email|max:255',
        ]);
        $macCount = Subscriber::where('email', $request->email)->count();
        if ($macCount > 0) {
            return back()->with('alert', 'This Email Already Exist !!');
        }else{
            Subscriber::create($request->all());
            return back()->with('success', ' Subscribe Successfully!');
        }
    }




    public function cronPlan()
    {
        $basic = GeneralSettings::first();
        $planLogs = PlanLog::where('end_time', '>=', Carbon::now())->whereStatus(1)->get();

        foreach ($planLogs as $planLog) {
            $userWallet = Wallet::where('user_id', $planLog->user_id)->where('mining_id', $planLog->mining_id)->first();
            if (!$userWallet) {
                continue;
            } else {

                $cronBal = ($planLog->pricingPlan->return_amount - $planLog->pricingPlan->electricity_charge) * $planLog->qty;
                $userWallet->balance = round(($userWallet->balance + $cronBal), $basic->decimal);
                $userWallet->save();

                $trx = Trx::create([
                    'user_id' => $planLog->user_id,
                    'amount' => $cronBal ,
                    'main_amo' => $userWallet->balance,
                    'mining_id' => $planLog->pricingPlan->mining->id,
                    'charge' => 0,
                    'type' => '+',
                    'title' => 'Added ' . $cronBal . " " . $planLog->pricingPlan->mining->name . ' By ' . $planLog->pricingPlan->title,
                    'trx' => strtoupper(str_random(20))
                ]);

                $text = $trx->title . "<br>" . " Your current balance " . $userWallet->balance . " " . $planLog->pricingPlan->mining->name;
                send_email($userWallet->user->email, $userWallet->user->name, "Add new Balance", $text);
                send_sms($userWallet->user->mobile, $text);
            }

        }


        $planLogsEndtime = PlanLog::where('end_time', '<', Carbon::now())->whereStatus(1)->get();
        foreach ($planLogsEndtime as $value) {
            $value->status = -1;
            $value->save();
        }

    }

    public function getPlan(Request $request){
        $item = PricingPlan::with('mining')->where('cat_id', $request->id)->get();
        return $item;
    }
}
