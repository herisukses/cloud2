<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EarnRevenue extends Model
{
    protected $table = "earn_revenues";

    protected  $guarded = [];
}
