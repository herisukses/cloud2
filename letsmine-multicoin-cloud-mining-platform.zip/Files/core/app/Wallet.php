<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wallet extends Model
{
    protected $guarded = [''];
    protected $table = "wallets";

    public function user()
    {
        return $this->belongsTo('App\User','user_id');
    }

    public function mining()
    {
        return $this->belongsTo('App\Mining','mining_id');
    }

}
