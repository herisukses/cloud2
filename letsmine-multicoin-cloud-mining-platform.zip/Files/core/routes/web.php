<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/cron', 'FrontendController@cronPlan')->name('cron.plan');


//Payment IPN

Route::get('/ipnbtc', 'PaymentController@ipnBchain')->name('ipn.bchain');
Route::get('/ipnblockbtc', 'PaymentController@blockIpnBtc')->name('ipn.block.btc');
Route::get('/ipnblocklite', 'PaymentController@blockIpnLite')->name('ipn.block.lite');
Route::get('/ipnblockdog', 'PaymentController@blockIpnDog')->name('ipn.block.dog');
Route::post('/ipnpaypal', 'PaymentController@ipnpaypal')->name('ipn.paypal');
Route::post('/ipnperfect', 'PaymentController@ipnperfect')->name('ipn.perfect');
Route::post('/ipnstripe', 'PaymentController@ipnstripe')->name('ipn.stripe');
Route::post('/ipnskrill', 'PaymentController@skrillIPN')->name('ipn.skrill');
Route::post('/ipncoinpaybtc', 'PaymentController@ipnCoinPayBtc')->name('ipn.coinPay.btc');
Route::post('/ipncoinpayeth', 'PaymentController@ipnCoinPayEth')->name('ipn.coinPay.eth');
Route::post('/ipncoinpaybch', 'PaymentController@ipnCoinPayBch')->name('ipn.coinPay.bch');
Route::post('/ipncoinpaydash', 'PaymentController@ipnCoinPayDash')->name('ipn.coinPay.dash');
Route::post('/ipncoinpaydoge', 'PaymentController@ipnCoinPayDoge')->name('ipn.coinPay.doge');
Route::post('/ipncoinpayltc', 'PaymentController@ipnCoinPayLtc')->name('ipn.coinPay.ltc');
Route::post('/ipncoin', 'PaymentController@ipnCoin')->name('ipn.coinpay');
Route::post('/ipncoingate', 'PaymentController@ipnCoinGate')->name('ipn.coingate');


Route::get('/', 'FrontendController@index')->name('homepage');
Route::get('/menu/{slug}', 'FrontendController@menu')->name('menu');
Route::get('/blog', 'FrontendController@blog')->name('blog');
Route::get('/details/{id}/{slug}', 'FrontendController@details')->name('blog.details');
Route::get('/pricing', 'FrontendController@pricing')->name('pricing');
Route::get('/cats/{id}/{slug}', 'FrontendController@categoryByBlog')->name('cats.blog');
Route::get('/about-us', 'FrontendController@about')->name('about');
Route::get('/faqs', 'FrontendController@faqs')->name('faqs');
Route::get('/click-add/{id}', 'FrontendController@clickadd');
Route::get('/contact-us', 'FrontendController@contactUs')->name('contact');
Route::post('/contact-us', ['uses' => 'FrontendController@contactSubmit', 'as' => 'contact-submit']);
Route::post('/subscribe', 'FrontendController@subscribe')->name('subscribe');


Auth::routes();

Route::group(['prefix' => 'user'], function () {

    Route::get('authorization', 'HomeController@authCheck')->name('user.authorization');

    Route::post('verification', 'HomeController@sendVcode')->name('user.send-vcode');
    Route::post('smsVerify', 'HomeController@smsVerify')->name('user.sms-verify');

    Route::post('verify-email', 'HomeController@sendEmailVcode')->name('user.send-emailVcode');
    Route::post('postEmailVerify', 'HomeController@postEmailVerify')->name('user.email-verify');


    Route::middleware(['CheckStatus'])->group(function () {
        Route::get('/home', 'HomeController@index')->name('home');
        Route::post('/purchase', 'HomeController@UserPurchasePlan')->name('UserPurchasePlan');
        Route::post('/confirm-purchase', 'HomeController@confirmPurchase')->name('confirmPurchase');
        Route::get('/wallet-settings', 'HomeController@walletSettings')->name('wallet.settings');
        Route::post('/wallet-settings', 'HomeController@walletSettingsUpdate')->name('wallet.settings.update');
        Route::get('/my-plan', 'HomeController@myPlan')->name('myPlan.history');

        Route::get('/deposit', ['uses' => 'HomeController@deposit', 'as' => 'deposit']);
        Route::post('/deposit-data-insert', 'HomeController@depositDataInsert')->name('deposit.data-insert');
        Route::get('/deposit-preview', 'HomeController@depositPreview')->name('user.deposit.preview');
        Route::post('/deposit-confirm', 'PaymentController@depositConfirm')->name('deposit.confirm');


        Route::get('/withdraw-fund', 'HomeController@withdrawMoney')->name('withdraw.money');
        Route::post('/withdraw-preview', 'HomeController@requestPreview')->name('withdraw.preview');
        Route::post('/withdraw-submit', 'HomeController@requestSubmit')->name('withdraw.submit');

        Route::get('/transaction-log', 'HomeController@activity')->name('user.trx');
        Route::get('/deposit-log', 'HomeController@depositLog')->name('user.depositLog');
        Route::get('/withdraw-log', 'HomeController@withdrawLog')->name('user.withdrawLog');

        Route::get('change-password', ['as' => 'user.change-password', 'uses' => 'HomeController@changePassword']);
        Route::post('change-password', ['as' => 'user.change-password', 'uses' => 'HomeController@submitPassword']);

        Route::get('edit-profile', ['as' => 'edit-profile', 'uses' => 'HomeController@editProfile']);
        Route::post('edit-profile', ['as' => 'edit-profile', 'uses' => 'HomeController@submitProfile']);
    });
});


Route::group(['prefix' => 'admin'], function () {
    Route::get('/', 'AdminLoginController@index')->name('admin.loginForm');
    Route::post('/', 'AdminLoginController@authenticate')->name('admin.login');
});


Route::group(['prefix' => 'admin', 'middleware' => 'auth:admin'], function () {



    Route::get('/dashboard', 'AdminController@dashboard')->name('admin.dashboard');


    Route::get('/subscribers', 'DashboardController@manageSubscribers')->name('manage.subscribers');
    Route::post('/update-subscribers', 'DashboardController@updateSubscriber')->name('update.subscriber');
    Route::get('/send-email', 'DashboardController@sendMail')->name('send.mail.subscriber');
    Route::post('/send-email', 'DashboardController@sendMailsubscriber')->name('send.email.subscriber');

    Route::get('/coin', 'DashboardController@category')->name('admin.category');
    Route::post('/coin', 'DashboardController@UpdateCategory')->name('update.category');

    Route::get('/unit', 'DashboardController@unit')->name('admin.unit');
    Route::post('/unit', 'DashboardController@UpdateUnit')->name('update.unit');

    Route::get('/plan-create', 'DashboardController@createPlan')->name('plan.create');
    Route::post('/plan-create', 'DashboardController@storePlan')->name('plan.store');
    Route::get('/plans', 'DashboardController@plans')->name('plan.all');
    Route::get('/plan-edit/{id}', 'DashboardController@editPlan')->name('plan.edit');
    Route::post('/plan-update', 'DashboardController@updatePlan')->name('plan.update');

//    Blog Controller
    Route::get('/post-category', 'PostController@category')->name('admin.cat');
    Route::post('/post-category', 'PostController@UpdateCategory')->name('update.cat');
    Route::get('blog', 'PostController@index')->name('admin.blog');
    Route::get('blog/create', 'PostController@create')->name('blog.create');
    Route::post('blog/create', 'PostController@store')->name('blog.store');
    Route::delete('blog/delete', 'PostController@destroy')->name('blog.delete');
    Route::get('blog/edit/{id}', 'PostController@edit')->name('blog.edit');
    Route::post('blog-update', 'PostController@updatePost')->name('blog.update');

    //    Testimonial Controller
    Route::get('testimonial', 'TestimonialController@index')->name('admin.testimonial');
    Route::get('testimonial/create', 'TestimonialController@create')->name('testimonial.create');
    Route::post('testimonial/create', 'TestimonialController@store')->name('testimonial.store');
    Route::delete('testimonial/delete', 'TestimonialController@destroy')->name('testimonial.delete');
    Route::get('testimonial/edit/{id}', 'TestimonialController@edit')->name('testimonial.edit');
    Route::post('testimonial-update', 'TestimonialController@updatePost')->name('testimonial.update');


    //Gateway
    Route::get('/gateway', 'GatewayController@show')->name('gateway');
    Route::post('/gateway', 'GatewayController@update')->name('update.gateway');

    //Deposit
    Route::get('/deposits', 'DepositController@index')->name('deposits');
    Route::get('/deposits/requests', 'DepositController@requests')->name('deposits.requests');
    Route::put('/deposit/approve/{id}', 'DepositController@approve')->name('deposit.approve');
    Route::get('/deposit/{deposit}/delete', 'DepositController@destroy')->name('deposit.destroy');

    //withdraw
    Route::get('/withdraw', 'WithdrawController@index')->name('withdraw');
    Route::post('/withdraw', 'WithdrawController@store')->name('add.withdraw.method');
    Route::post('/withdraw-update', 'WithdrawController@withdrawUpdateSettings')->name('update.wsettings');

    Route::get('/withdraw/requests', 'WithdrawController@requests')->name('withdraw.requests');
    Route::get('/withdraw/approved', 'WithdrawController@requestsApprove')->name('withdraw.approved');
    Route::get('/withdraw/refunded', 'WithdrawController@requestsRefunded')->name('withdraw.refunded');

    Route::put('/withdraw/approve/{id}', 'WithdrawController@approve')->name('withdraw.approve');
    Route::post('/withdraw/refund', 'WithdrawController@refundAmount')->name('withdraw.refund');


    //Email Template
    Route::get('/template', 'EtemplateController@index')->name('email.template');
    Route::post('/template-update', 'EtemplateController@update')->name('template.update');
    //Sms Api
    Route::get('/sms-api', 'EtemplateController@smsApi')->name('sms.api');
    Route::post('/sms-update', 'EtemplateController@smsUpdate')->name('sms.update');


    // General Settings
    Route::get('/general-settings', 'GeneralSettingController@GenSetting')->name('admin.GenSetting');
    Route::post('/general-settings', 'GeneralSettingController@UpdateGenSetting')->name('admin.UpdateGenSetting');
    Route::get('/change-password', 'GeneralSettingController@changePassword')->name('admin.changePass');
    Route::post('/change-password', 'GeneralSettingController@updatePassword')->name('admin.changePass');
    Route::get('/profile', 'GeneralSettingController@profile')->name('admin.profile');
    Route::post('/profile', 'GeneralSettingController@updateProfile')->name('admin.profile');


    //User Management
    Route::get('users', 'GeneralSettingController@users')->name('users');
    Route::post('user-search', 'GeneralSettingController@userSearch')->name('search.users');
    Route::get('user/{user}', 'GeneralSettingController@singleUser')->name('user.single');
    Route::put('user/pass-change/{user}', 'GeneralSettingController@userPasschange')->name('user.passchange');
    Route::put('user/status/{user}', 'GeneralSettingController@statupdate')->name('user.status');
    Route::get('mail/{user}', 'GeneralSettingController@userEmail')->name('user.email');
    Route::post('/sendmail', 'GeneralSettingController@sendemail')->name('send.email');
    Route::get('/user-login-history/{id}', 'GeneralSettingController@loginLogsByUsers')->name('user.login.history');
    Route::get('/user-balance/{id}', 'GeneralSettingController@ManageBalanceByUsers')->name('user.balance');
    Route::post('/user-balance', 'GeneralSettingController@saveBalanceByUsers')->name('user.balance.update');
    Route::get('/user-banned',  'GeneralSettingController@banusers')->name('user.ban');
    Route::get('login-logs/{user?}', 'GeneralSettingController@loginLogs')->name('user.login-logs');

    Route::get('/user-transaction/{id}', 'GeneralSettingController@userTrans')->name('user.trans');
    Route::get('/user-deposit/{id}',  'GeneralSettingController@userDeposit')->name('user.deposit');
    Route::get('/user-withdraw/{id}', 'GeneralSettingController@userWithdraw')->name('user.withdraw');


    //Contact Setting
    Route::get('contact-setting',  'WebSettingController@getContact')->name('contact-setting');
    Route::put('contact-setting/{id}', 'WebSettingController@putContactSetting')->name('contact-setting-update');

    Route::get('manage-logo','WebSettingController@manageLogo')->name('manage-logo');
    Route::post('manage-logo','WebSettingController@updateLogo')->name('manage-logo');

    Route::get('manage-footer-text', 'WebSettingController@manageFooter')->name('manage-footer');
    Route::put('manage-footer-text', 'WebSettingController@updateFooter')->name('manage-footer-update');

    Route::get('manage-social','WebSettingController@manageSocial')->name('manage-social');
    Route::post('manage-social','WebSettingController@storeSocial')->name('manage-social');
    Route::get('manage-social/{product_id?}','WebSettingController@editSocial')->name('social-edit');
    Route::put('manage-social/{product_id?}', 'WebSettingController@updateSocial')->name('social-edit');
    Route::post('delete-social', 'WebSettingController@destroySocial')->name('del.social');

    Route::get('menu-create', 'WebSettingController@createMenu')->name('menu-create');
    Route::post('menu-create', 'WebSettingController@storeMenu')->name('menu-create');
    Route::get('menu-control', 'WebSettingController@manageMenu')->name('menu-control');
    Route::get('menu-edit/{id}', 'WebSettingController@editMenu')->name('menu-edit');
    Route::post('menu-update/{id}', 'WebSettingController@updateMenu')->name('menu-update');
    Route::delete('menu-delete',  'WebSettingController@deleteMenu')->name('menu-delete');


    Route::get('manage-breadcrumb', ['as' => 'manage-breadcrumb', 'uses' => 'WebSettingController@mangeBreadcrumb']);
    Route::post('manage-breadcrumb', ['as' => 'manage-breadcrumb', 'uses' => 'WebSettingController@updateBreadcrumb']);

    Route::get('manage-about', ['as' => 'manage-about', 'uses' => 'WebSettingController@manageAbout']);
    Route::post('manage-about', ['as' => 'manage-about', 'uses' => 'WebSettingController@updateAbout']);

    Route::get('manage-privacy', ['as' => 'manage-privacy', 'uses' => 'WebSettingController@managePrivacy']);
    Route::post('manage-privacy', ['as' => 'manage-privacy', 'uses' => 'WebSettingController@updatePrivacy']);

    Route::get('manage-terms', ['as' => 'manage-terms', 'uses' => 'WebSettingController@manageTerms']);
    Route::post('manage-terms', ['as' => 'manage-terms', 'uses' => 'WebSettingController@updateTerms']);


    Route::get('section-1', ['as' => 'section1',  'uses' =>'TemplateSetupController@section1']);
    Route::put('section-1', ['as' => 'section1',  'uses' =>'TemplateSetupController@updSection1']);

    Route::get('section-2', ['as' => 'wayToEarn',  'uses' =>'TemplateSetupController@wayToEarn']);
    Route::get('section-2/create', ['as' => 'create.wayToEarn',  'uses' =>'TemplateSetupController@createWayToEarn']);
    Route::post('section-2/create', ['as' => 'store.wayToEarn',  'uses' =>'TemplateSetupController@storeWayToEarn']);
    Route::get('section-2/{id}', ['as' => 'edit.wayToEarn',  'uses' =>'TemplateSetupController@editWayToEarn']);
    Route::post('section-2/{id}', ['as' => 'update.wayToEarn',  'uses' =>'TemplateSetupController@updateWayToEarn']);
    Route::delete('section-2', ['as' => 'delete.wayToEarn',  'uses' =>'TemplateSetupController@deleteWayToEarn']);

    //Manage How-it-work
    Route::get('section-3', ['as' => 'howItWorks',  'uses' =>'TemplateSetupController@index']);
    Route::get('section-3/{id}', ['as' => 'edit.howItWorks',  'uses' =>'TemplateSetupController@editHowItWork']);
    Route::post('section-3/{id}', ['as' => 'update.howItWorks',  'uses' =>'TemplateSetupController@updateHowItWork']);


    Route::get('features', ['as' => 'features',  'uses' =>'TemplateSetupController@features']);
    Route::get('features/{id}', ['as' => 'edit.features',  'uses' =>'TemplateSetupController@editFeatures']);
    Route::post('features/{id}', ['as' => 'update.features',  'uses' =>'TemplateSetupController@updateFeatures']);

    Route::get('section-4', ['as' => 'reward', 'uses' => 'TemplateSetupController@reward']);
    Route::post('section-4/{id}', ['as' => 'update.reward', 'uses' => 'TemplateSetupController@updateReward']);

    Route::get('section-5', ['as' => 'integration', 'uses' => 'TemplateSetupController@integration']);
    Route::post('section-5/{id}', ['as' => 'integration1', 'uses' => 'TemplateSetupController@updateOneIntegration']);



    Route::get('section-6', ['as' => 'get-started', 'uses' => 'TemplateSetupController@manageGetStarted']);
    Route::put('section-6/{id}', ['as' => 'get-started-update', 'uses' => 'TemplateSetupController@updateGetStarted']);


    Route::get('our-client', ['as' => 'our.client',  'uses' =>'TemplateSetupController@ourClient']);
    Route::post('our-client', ['as' => 'store.client',  'uses' =>'TemplateSetupController@storeClient']);
    Route::delete('our-client', ['as' => 'delete.client',  'uses' =>'TemplateSetupController@deleteClient']);


    Route::get('our-team', ['as' => 'team',  'uses' =>'TemplateSetupController@ourTeam']);
    Route::get('our-team/create', ['as' => 'create.team',  'uses' =>'TemplateSetupController@createOurTeam']);
    Route::post('our-team/create', ['as' => 'store.team',  'uses' =>'TemplateSetupController@storeOurTeam']);
    Route::get('our-team/{id}', ['as' => 'edit.team',  'uses' =>'TemplateSetupController@editOurTeam']);
    Route::post('our-team/{id}', ['as' => 'update.team',  'uses' =>'TemplateSetupController@updateOurTeam']);
    Route::delete('our-team', ['as' => 'delete.team',  'uses' =>'TemplateSetupController@deleteOurTeam']);



    Route::get('faqs-create', 'WebSettingController@createFaqs')->name('faqs-create');
    Route::post('faqs-create', 'WebSettingController@storeFaqs')->name('faqs-create');
    Route::get('faqs-all', 'WebSettingController@allFaqs')->name('faqs-all');
    Route::get('faqs-edit/{id}', 'WebSettingController@editFaqs')->name('faqs-edit');
    Route::put('faqs-edit/{id}', 'WebSettingController@updateFaqs')->name('faqs-update');
    Route::delete('faqs-delete', 'WebSettingController@deleteFaqs')->name('faqs-delete');

    Route::resource('advertisement', 'AdvertisementController');



    Route::get('/logout', 'AdminController@logout')->name('admin.logout');
});


## Modal Login & Registration Route##
Route::post('/modal-login', 'CustomLoginController@login')->name('modal.login');
Route::post('/modal-register', 'CustomRegisterController@register')->name('modal.register');
/*============== User Password Reset Route list ===========================*/
Route::get('user-password/reset', 'User\ForgotPasswordController@showLinkRequestForm')->name('user.password.request');
Route::post('user-password/email', 'User\ForgotPasswordController@sendResetLinkEmail')->name('user.password.email');
Route::get('user-password/reset/{token}', 'User\ResetPasswordController@showResetForm')->name('user.password.reset');
Route::post('user-password/reset', 'User\ResetPasswordController@reset');

Route::post('get-plan', 'FrontendController@getPlan')->name('get.plan');


