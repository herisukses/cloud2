@extends('admin.layout.master')
@section('css')
@stop
@section('body')


    <div class="row">
        @foreach($howItworks as $key => $data)
            <div class="col-md-4">

                <div class="tile">
                    <div class="tile-title text-center">
                        <h3 class="title">{{$data->title}}</h3>
                    </div>
                    <div class="tile-body">
                        <p>{{$data->details}}</p>
                    </div>
                    <div class="tile-footer">
                        <a class="btn btn-primary btn-block" href="{{route('edit.howItWorks',$data->id)}}">
                            <i class="fa fa-pencil"></i> Edit
                        </a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>




@stop
@section('script')
@stop