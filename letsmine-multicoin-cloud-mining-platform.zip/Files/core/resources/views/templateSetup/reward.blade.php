@extends('admin.layout.master')
@section('import-css')
    <link href="{{ asset('assets/admin/css/bootstrap-fileinput.css') }}" rel="stylesheet">
@stop
@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <div class="tile-body">

                    <form action="{{route('update.reward',$basic->id)}}" method="post" enctype="multipart/form-data">
                        {{csrf_field()}}
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group{{ $errors->has('reward_title') ? ' has-error' : '' }}">
                                    <label class="col-md-12"><strong class="text-uppercase">Title</strong></label>
                                    <div class="col-md-12">
                                        <input type="reward_title" name="reward_title" class="form-control"
                                               value="{{ $basic->reward_title }}" required>
                                        @if ($errors->has('reward_title'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('reward_title') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>


                                <div class="form-group{{ $errors->has('reward_image') ? ' has-error' : '' }}">
                                    <label class="col-md-12"><strong class="text-uppercase">Image</strong></label>

                                    <div class="col-md-12">
                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;"
                                                 data-trigger="fileinput">
                                                @if($basic->reward_image == null)
                                                    <img style="width: 200px"
                                                         src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=Fetured Image"
                                                         alt="...">
                                                @else
                                                    <img style="width: 200px"
                                                         src="{{ asset('assets/images') }}/{{ $basic->reward_image }}"
                                                         alt="...">
                                                @endif
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail"
                                                 style="max-width: 200px; max-height: 150px"></div>
                                            <div>
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i
                                                                class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i
                                                                class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="reward_image" accept="image/*">
                                                </span>
                                                <a href="#" class="btn btn-danger fileinput-exists bold uppercase"
                                                   data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>
                                            </div>
                                        </div>
                                        @if ($errors->has('reward_image'))
                                            <div class="error">{{ $errors->first('reward_image') }}</div>
                                        @endif

                                    </div>
                                </div>


                                <div class="form-group{{ $errors->has('reward_details') ? ' has-error' : '' }}">
                                    <label class="col-md-12"><strong class="text-uppercase">Details</strong></label>
                                    <div class="col-md-12">
                                        <textarea name="reward_details" rows="5" class="form-control"
                                                  required>{{ $basic->reward_details }}</textarea>
                                        @if ($errors->has('reward_details'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('reward_details') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary btn-block btn-lg"><i
                                                    class="fa fa-send"></i> UPDATE
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>



@stop

@section('import-script')
    <script src="{{ asset('assets/admin/js/bootstrap-fileinput.js') }}"></script>
@stop