@extends('admin.layout.master')
@section('import-css')
    <link href="{{ asset('assets/admin/css/bootstrap-fileinput.css') }}" rel="stylesheet">
@stop
@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <div class="tile-body">

                    {!! Form::model($basic,['route'=>['get-started-update',$basic->id],'method'=>'PUT','role'=>'form','class'=>'form-horizontal','files'=>true]) !!}

                        <div class="row">
                            <div class="col-md-12">

                                <div class="form-group{{ $errors->has('get_started_title') ? ' has-error' : '' }}">
                                    <label class="col-md-12"><strong class="text-uppercase">Title</strong></label>
                                    <div class="col-md-12">
                                        <input type="text" name="get_started_title" class="form-control" value="{{ $basic->get_started_title }}" required>
                                        @if ($errors->has('get_started_title'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('get_started_title') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>

                                <div class="form-group{{ $errors->has('	get_started_sub_title') ? ' has-error' : '' }}">
                                    <label class="col-md-12"><strong class="text-uppercase">Sub-Title</strong></label>
                                    <div class="col-md-12">
                                        <input type="text" name="get_started_sub_title" class="form-control" value="{{ $basic->get_started_sub_title }}" required>
                                        @if ($errors->has('	get_started_sub_title'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('get_started_sub_title') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>


                                <div class="form-group{{ $errors->has('get_started_details') ? ' has-error' : '' }}">
                                    <label class="col-md-12"><strong class="text-uppercase">Details</strong></label>
                                    <div class="col-md-12">
                                        <textarea name="get_started_details" rows="5" class="form-control" required>{{ $basic->get_started_details }}</textarea>
                                        @if ($errors->has('get_started_details'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('get_started_details') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>



                                <div class="form-group">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fa fa-send"></i> UPDATE</button>
                                    </div>
                                </div>
                            </div>
                        </div><!-- row -->

                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>


@stop

@section('import-script')
    <script src="{{ asset('assets/admin/js/bootstrap-fileinput.js') }}"></script>
@stop