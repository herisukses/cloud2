@extends('admin.layout.master')
@section('import-css')
    <link href="{{ asset('assets/admin/css/bootstrap-fileinput.css') }}" rel="stylesheet">
@stop
@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <h3 class="tile-title ">{{$page_title}}
                    <a href="{{route('howItWorks')}}" class="btn btn-success btn-md pull-right ">
                    <i class="fa fa-eye"></i> Back
                    </a>
                </h3>
                <div class="tile-body">
                    <form role="form" method="POST" action="{{route('update.howItWorks',$post->id)}}" name="editForm" enctype="multipart/form-data">
                        {{ csrf_field() }}

                        <div class="row">
                            <div class="col-md-12">
                                <h6> Title</h6>
                                <div class="input-group">
                                    <input type="text" class="form-control input-lg" value="{{$post->title}}"
                                           name="title">
                                    <div class="input-group-append"><span class="input-group-text">
                                            <i class="fa fa-font"></i>
                                            </span>
                                    </div>
                                </div>
                                @if ($errors->has('title'))
                                    <div class="error">{{ $errors->first('title') }}</div>
                                @endif

                            </div>
                        </div>
                        <br>

                        <div class="row">
                            <div class="col-md-12">
                                <h6>Details</h6>

                                <textarea name="details"  rows="6" class="form-control">{{$post->details}}</textarea>
                                @if ($errors->has('details'))
                                    <div class="error">{{ $errors->first('details') }}</div>
                                @endif
                            </div>

                        </div><br>
                        <br>
                        <div class="row">
                            <hr/>
                            <div class="col-md-12 ">
                                <button class="btn btn-primary btn-block btn-lg">Update </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('import-script')
    <script src="{{ asset('assets/admin/js/bootstrap-fileinput.js') }}"></script>
@stop
@section('script')
@stop