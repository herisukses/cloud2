@extends('admin.layout.master')
@section('import-css')
    <link href="{{ asset('assets/admin/css/bootstrap-fileinput.css') }}" rel="stylesheet">
@stop
@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <div class="tile-body">

                    {!! Form::model($basic,['route'=>['section1'],'method'=>'PUT','role'=>'form','class'=>'form-horizontal','files'=>true]) !!}

                        <div class="row">
                            <div class="col-md-12">

                                <div class="form-group{{ $errors->has('breadcrumb_text') ? ' has-error' : '' }}">
                                    <label class="col-md-12"><strong class="text-uppercase">Title</strong></label>
                                    <div class="col-md-12">
                                        <textarea name="breadcrumb_text"  class="form-control" required>{{ $basic->breadcrumb_text }}</textarea>
                                        @if ($errors->has('breadcrumb_text'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('breadcrumb_text') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>

                                <div class="form-group{{ $errors->has('breadcrumb_text2') ? ' has-error' : '' }}">
                                    <label class="col-md-12"><strong class="text-uppercase">Sub-title</strong></label>
                                    <div class="col-md-12">
                                        <textarea name="breadcrumb_text2"  class="form-control" required>{{ $basic->breadcrumb_text2 }}</textarea>
                                        @if ($errors->has('breadcrumb_text2'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('breadcrumb_text2') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <h6>Image</h6>
                                    <div class="fileinput fileinput-new" data-provides="fileinput">
                                        <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;" data-trigger="fileinput">
                                            <img style="width: 200px" src="{{ asset('assets/images/logo/header-vector.png') }}" alt="...">
                                        </div>
                                        <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
                                        <div>
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="header_vector" accept="image/*" >
                                                </span>
                                            <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>
                                        </div>
                                    </div>
                                    @if ($errors->has('header_vector'))
                                        <div class="error">{{ $errors->first('header_vector') }}</div>
                                    @endif
                                </div>

                                <div class="form-group">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fa fa-send"></i> UPDATE</button>
                                    </div>
                                </div>
                            </div>
                        </div><!-- row -->

                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>


@stop


@section('import-script')
    <script src="{{ asset('assets/admin/js/bootstrap-fileinput.js') }}"></script>
@stop