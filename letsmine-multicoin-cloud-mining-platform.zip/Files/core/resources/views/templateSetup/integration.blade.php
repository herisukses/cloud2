@extends('admin.layout.master')
@section('import-css')
    <link href="{{ asset('assets/admin/css/bootstrap-fileinput.css') }}" rel="stylesheet">
@stop
@section('body')
    <div class="row">
        <div class="col-md-12">
            @include('errors.error')
            <div class="tile">
                <div class="tile-body">

                    <form action="{{route('integration1',$integrationStep1->id)}}" method="post" enctype="multipart/form-data">
                        {{csrf_field()}}
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group{{ $errors->has('val1') ? ' has-error' : '' }}">
                                    <label class="col-md-12"><strong class="text-uppercase">Title</strong></label>
                                    <div class="col-md-12">
                                        <input type="text" name="val1" class="form-control" value="{{ $integrationStep1->val1 }}" required>
                                        @if ($errors->has('val1'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('val1') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>

                                <div class="form-group{{ $errors->has('val3') ? ' has-error' : '' }}">
                                    <label class="col-md-12"><strong class="text-uppercase">Sub Title</strong></label>
                                    <div class="col-md-12">
                                        <input type="text" name="val3" class="form-control" value="{{ $integrationStep1->val3 }}" required>
                                        @if ($errors->has('val3'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('val3') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>


                                <div class="form-group{{ $errors->has('val2') ? ' has-error' : '' }}">
                                    <label class="col-md-12"><strong class="text-uppercase">Details</strong></label>
                                    <div class="col-md-12">
                                        <textarea name="val2" rows="5" class="form-control" required>{{ $integrationStep1->val2 }}</textarea>
                                        @if ($errors->has('val2'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('val2') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fa fa-send"></i> UPDATE</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <div class="row">
        @foreach($integrationStep2 as $key => $data)
            <div class="col-md-4">
                <div class="tile">
                    <div class="tile-title text-center">

                        <img src="{{asset('assets/images/'.$data->image)}}" width="20%" alt="Card image cap"><br><br>
                        <h5 class="title">{{$data->val1}}</h5>
                    </div>
                    <div class="tile-body">

                        <p>{{$data->val2}}</p>
                    </div>
                    <div class="tile-footer text-center">
                        <button class="btn btn-primary btn-block edit_button"
                                data-toggle="modal" data-target="#editModal{{$data->id}}"
                            <i class="fa fa-pencil"></i> Edit
                        </button>
                    </div>
                </div>
            </div>


            <div class="modal fade editModal" id="editModal{{$data->id}}" tabindex="-1"
            role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">

                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel">Edit
                            <strong>{{$gateway->name or ''}}</strong></h4>
                        <button type="button" class="close" data-dismiss="modal"
                                aria-hidden="true">&times;
                        </button>
                    </div>
                    <form method="post" action="{{route('integration1',$data->id)}}"
                          enctype="multipart/form-data">
                        {{ csrf_field() }}

                        <div class="modal-body">
                            <div class="form-group">
                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                    <div class="fileinput-new thumbnail">
                                        <img src="{{ asset('assets/images') }}/{{$data->image}}"
                                             alt="*"/></div>
                                    <div class="fileinput-preview fileinput-exists thumbnail"
                                         style="max-width: 200px; max-height: 200px;"></div>
                                    <div>
                                                        <span class="btn btn-success btn-file">
                                                            <span class="fileinput-new"> Change Logo </span>
                                                            <span class="fileinput-exists"> Change </span>
                                                            <input type="file" name="image"> </span>
                                        <a href="javascript:;" class="btn btn-danger fileinput-exists"
                                           data-dismiss="fileinput"> Remove </a>
                                    </div>
                                </div>
                            </div>

                                <div class="form-group">
                                    <h6 for="val1"><strong>Title</strong></h6>
                                    <input type="text" value="{{$data->val1 or ''}}"
                                           class="form-control" id="val1" name="val1">
                                </div>

                                <div class="form-group">
                                    <h6 for="val1"><strong>Details</strong></h6>
                                    <textarea class="form-control" id="val2" name="val2" rows="5">
                                        {{$data->val2 }}
                                    </textarea>
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success ">Save Changes</button>
                            <button type="button" class=" btn btn-danger" data-dismiss="modal"
                                    aria-hidden="true">Close
                            </button>
                        </div>
                    </form>
                </div>
            </div>
    </div>
        @endforeach
    </div>


@stop

@section('import-script')
    <script src="{{ asset('assets/admin/js/bootstrap-fileinput.js') }}"></script>
@stop