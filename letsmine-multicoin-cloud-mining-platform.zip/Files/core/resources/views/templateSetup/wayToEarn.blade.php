@extends('admin.layout.master')
@section('css')
@stop
@section('body')
    <div class="row">
        <div class="col-md-12">

            <div class="tile">

               <div class="row"> <div class="col-md-12">
                       <a href="{{route('create.wayToEarn')}}" class="btn btn-success btn-md pull-right ">
                           <i class="fa fa-plus"></i> Create New
                       </a>
                   </div></div>
                <div class="tile-body">

                    {!! Form::model($basic,['route'=>['manage-footer-update'],'method'=>'PUT','role'=>'form','class'=>'form-horizontal','files'=>true]) !!}

                    <div class="row">
                        <div class="col-md-12">



                            <div class="form-group{{ $errors->has('earn_revenues_title') ? ' has-error' : '' }}">
                                <label class="col-md-12"><strong class="text-uppercase">Title</strong></label>
                                <div class="col-md-12">
                                    <textarea name="earn_revenues_title" class="form-control" required>{{ $basic->earn_revenues_title }}</textarea>
                                    @if ($errors->has('earn_revenues_title'))
                                        <span class="help-block">
                                                <strong>{{ $errors->first('earn_revenues_title') }}</strong>
                                            </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('earn_revenues_sub_title') ? ' has-error' : '' }}">
                                <label class="col-md-12"><strong class="text-uppercase">Sub title</strong></label>
                                <div class="col-md-12">
                                    <textarea name="earn_revenues_sub_title" class="form-control" required>{{ $basic->earn_revenues_sub_title }}</textarea>
                                    @if ($errors->has('earn_revenues_sub_title'))
                                        <span class="help-block">
                                                <strong>{{ $errors->first('earn_revenues_sub_title') }}</strong>
                                            </span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fa fa-send"></i> UPDATE</button>
                                </div>
                            </div>
                        </div>
                    </div><!-- row -->

                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        @foreach($earnRevenue as $key => $data)
            <div class="col-md-4">
                <div class="tile">
                    <div class="tile-title text-center">

                        <img src="{{asset('assets/images/'.$data->image)}}" width="40%" alt="Card image cap"><br><br>
                        <h3 class="title">{{$data->title}}</h3>
                    </div>
                    <div class="tile-body">

                        <h3 class="title  text-center">{!! $data->icon !!}</h3>
                        <p>{{$data->details}}</p>
                    </div>
                    <div class="tile-footer text-center">
                        <a class="btn btn-primary " href="{{route('edit.wayToEarn',$data->id)}}">
                            <i class="fa fa-pencil"></i> Edit
                        </a>
                        <button class="btn btn-danger delete_button"
                           data-toggle="modal" data-target="#DelModal"
                           data-id="{{ $data->id }}">
                            <i class="fa fa-trash"></i> Delete
                        </button>
                    </div>
                </div>
            </div>
        @endforeach
    </div>



    <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content" >
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel2"><i class='fa fa-trash'></i> Delete !</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Delete ?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="{{ route('delete.wayToEarn') }}" >
                        {!! csrf_field() !!}
                        {{ method_field('DELETE') }}
                        <input type="hidden" name="id" class="abir_id" value="0">

                        <button type="submit" class="btn btn-success"><i class="fa fa-check"></i> Yes</button>

                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-trash"></i> No</button>&nbsp;
                    </form>
                </div>

            </div>
        </div>
    </div>

@stop
@section('script')
    <script>
        $(document).ready(function () {
            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);
            });
        });
    </script>
@stop