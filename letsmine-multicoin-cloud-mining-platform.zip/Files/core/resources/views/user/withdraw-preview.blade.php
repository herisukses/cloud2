@extends('user')
@section('content')
    @include('partials.breadcrumb')
    <div class="price">
        <div class="container">


            <div class="row">

                <div class="col-xl-12 col-lg-12">

                    <div class="tab-content" id="myTabContent2">
                        <div class="tab-pane fade show active" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
                            <div class="row">

                                <div class="col-md-12">
                                    <div class="single-price">
                                        <div class="part-top">
                                            <h4> <strong>{{ round($balance->balance ,$basic->decimal)}}
                                                    - {{ $basic->currency }}</strong></h4>
                                        </div>

                                        <form method="post" action="{{route('withdraw.submit')}}">
                                            {{ csrf_field() }}
                                        <div class="part-bottom">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label class="bold uppercase text-right control-label">Request Amount : </label>

                                                    <div class="input-group">
                                                        <input type="text" value="{{ $withdraw->amount }}" readonly
                                                               id="amount" class="form-control bold custom-input "
                                                               placeholder="Enter Deposit Amount"
                                                               required>
                                                        <div class="input-group-prepend ">
                                                            <span class="input-group-text custom-input">&nbsp;<strong> {{ $method->mining->coin_code }}</strong></span>
                                                        </div>
                                                    </div>


                                                    <label class="text-right bold uppercase control-label">Withdraw Charge
                                                        : </label>
                                                    <div class="input-group">
                                                        <input type="text" value="{{ round($withdraw->charge,$basic->decimal )}}"
                                                               readonly  id="charge" class="form-control bold custom-input"
                                                               placeholder="Enter Deposit Amount" required>
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text custom-input">&nbsp;<strong> {{ $method->mining->coin_code }} </strong></span>
                                                        </div>
                                                    </div>


                                                    <label class="bold uppercase text-right control-label">Total Amount : </label>

                                                    <div class="input-group">
                                                        <input type="text" value="{{ $withdraw->net_amount }}" readonly
                                                               id="charge" class="form-control bold custom-input"
                                                               placeholder="Enter Deposit Amount"
                                                               required>
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text custom-input">&nbsp;<strong>{{ $method->mining->coin_code }} </strong></span>
                                                        </div>
                                                    </div>


                                                    <label class="bold uppercase text-right control-label">Available Balance
                                                        : </label>

                                                    <div class="input-group">
                                                        <input type="text"
                                                               value="{{ round($balance->balance, $basic->decimal) - $withdraw->net_amount }}"
                                                               readonly  id="charge" class="form-control bold custom-input"
                                                               placeholder="Enter Deposit Amount" required>
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text custom-input">&nbsp;<strong> {{ $method->mining->coin_code }} </strong></span>
                                                        </div>
                                                    </div>

                                                </div>

                                                <div class="col-md-6">
                                                    <input type="hidden" name="withdraw_id" value="{{ $withdraw->id }}">
                                                    <div class="form-group">
                                                        <label class="bold uppercase  control-label">{{ $method->mining->coin_code }}
                                                            Account : </label>
                                                        <input type="text" name="send_details"  class="form-control custom-input bold input-lg {{ $errors->has('send_details') ? 'has-error' : ''}}" placeholder="Enter Your Account Info " >
                                                        <span class="error">{{ $errors->first('send_details') }}</span>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="bold uppercase text-right control-label">Message: </label>
                                                        <textarea name="message"  rows="6"
                                                                  class="form-control bold input-lg custom-input"
                                                                  placeholder="Message ( If Any )"></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <br>
                                                    <button type="submit" class="btn btn-primary btn-lg  custom-btn bold uppercase btn-block">
                                                        <i class="fa fa-send"></i> Submit Withdraw
                                                    </button>

                                                </div>
                                            </div>

                                        </div>


                                        </form>



                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
@stop