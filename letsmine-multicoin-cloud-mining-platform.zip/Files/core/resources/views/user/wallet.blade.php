@extends('user')

@section('content')
    @include('partials.breadcrumb')

    <div class="price">
        <div class="container">
            <div class="row">

                <div class="col-xl-12 col-lg-12">

                    <div class="tab-content" id="myTabContent2">
                        <div class="tab-pane fade show active" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">

                            {!! Form::open(['method'=>'post','role'=>'form','name' =>'editForm', 'files'=>true]) !!}
                            @foreach($wallets->chunk(2) as $items)

                                <div class="row">
                                    @foreach($items as $wallet)
                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                        <div class="single-price special">
                                            <div class="part-top">
                                                <h3>{{$wallet->mining->coin_code}} Wallet</h3>
                                            </div>
                                            <div class="part-bottom">
                                                <input type="hidden" name="id[]" value="{{$wallet->id}}">
                                                <input type="text" name="wallet_acc[]" value="{{$wallet->wallet_acc}}"
                                                       class="form-control"
                                                       placeholder="Enter Your {{$wallet->mining->name}}  Account">
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                            @endforeach

                            <br>
                            <br>

                                    @if(count($wallets) >0)
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <button type="submit" class="submit-btn btn btn-primary">Update Wallet</button>
                                            </div>
                                        </div>
                                    @else

                                        <div class="row">
                                            <div class="col-lg-12">
                                                <h3 class="text-danger text-center">You have no wallet yet !</h3>
                                            </div>
                                        </div>
                                    @endif

                                {!! Form::close() !!}

                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

@endsection
@section('script')

@endsection
