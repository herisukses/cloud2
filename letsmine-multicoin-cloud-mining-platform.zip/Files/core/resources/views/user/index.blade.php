@extends('user')
@section('content')
    @include('partials.breadcrumb')
    <!-- about begin -->
    <div class="about">
        <div class="container">

            <div class="row">

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <div class="single-about">
                        <div class="heading">
                            <div class="part-icon">
                                <i class="fas fa-money-check-alt"></i>
                            </div>
                            <div class="part-text">
                                <h3>Current Balance</h3>
                            </div>
                        </div>
                        <h4 class="text-center"> <span class="count-num">{{round(Auth::user()->balance , $basic->decimal)}}</span>
                            <span class="count-num-text"> {{$basic->currency_sym}}</span></h4>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <div class="single-about">
                        <div class="heading">
                            <div class="part-icon">
                                <i class="far fa-money-bill-alt"></i>
                            </div>
                            <div class="part-text">
                                <h3>Total Deposit</h3>
                            </div>
                        </div>
                        <h4 class="text-center">
                            <span class="count-num">{{round($deposit , $basic->decimal)}}</span>
                            <span class="count-num-text"> {{$basic->currency_sym}}</span>
                        </h4>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <a href="{{url('/pricing')}}">
                        <div class="single-about">
                            <div class="heading">
                                <div class="part-icon">
                                    <i class="fas fa-briefcase"></i>
                                </div>
                                <div class="part-text">
                                    <h3>Total Packages</h3>
                                </div>
                            </div>
                            <h4 class="text-center">
                                <span class="count-num">{{$package}}</span>

                            </h4>
                        </div>
                    </a>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <a href="{{url('/user/deposit')}}">
                        <div class="single-about">
                            <div class="heading">
                                <div class="part-icon">
                                    <i class="fas fa-credit-card"></i>
                                </div>
                                <div class="part-text">
                                    <h3>Deposit Methods</h3>
                                </div>
                            </div>
                            <h4 class="text-center">
                                <span class="count-num">{{$gateway}}</span>
                            </h4>
                        </div>
                    </a>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <a href="{{url('/user/my-plan')}}">
                        <div class="single-about">
                            <div class="heading">
                                <div class="part-icon">
                                    <i class="fas fa-shopping-cart"></i>
                                </div>
                                <div class="part-text">
                                    <h3>Purchase History</h3>
                                </div>
                            </div>
                            <h4 class="text-center">
                                <span class="count-num">{{$pur}}</span>
                            </h4>
                        </div>
                    </a>
                </div>





                @foreach($wallets as $wallet)

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <div class="single-about">
                        <div class="heading">
                            <div class="part-icon">
                                <i class="fas fa-hand-holding-usd"></i>
                            </div>
                            <div class="part-text">
                                <h3>{{$wallet->mining->name}} Balance</h3>
                            </div>
                        </div>
                        <h4 class="text-center">
                            <span class="count-num">{{$wallet->balance}}</span>
                            <span class="count-num-text">{{$wallet->mining->coin_code}}</span>
                        </h4>
                    </div>
                </div>

                @endforeach


            </div>
        </div>
    </div>
    <!-- about end -->

@stop