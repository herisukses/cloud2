@extends('user')
@section('content')
    @include('partials.breadcrumb')
    <div class="transaction">
        <div class="container">


            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="transaction-area">

                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="deposit" role="tabpanel" aria-labelledby="home-tab">

                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Purchase Date</th>
                                        <th scope="col">Miner Name</th>
                                        <th scope="col">Total Price</th>
                                        <th scope="col">Speed</th>
                                        <th scope="col">Coin Name</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Expired Date</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @if(count($myPlan) >0)

                                        @foreach($myPlan as $k=>$data)
                                            <tr>
                                                <td data-label="SL">{{++$k}}</td>
                                                <td data-label="Purchase Date">{{   date(' d F, Y h:s A', strtotime($data->created_at))}}</td>
                                                <td data-label="Title">{!! $data->pricingPlan->title  or '' !!}</td>
                                                <td data-label="Price">{{number_format(($data->pricingPlan->rate * $data->qty), $basic->decimal)}} {{$basic->currency}}</td>
                                                <td data-label="Speed">{{$data->qty .' '. $data->pricingPlan->unit->name}}</td>
                                                <td data-label="Miner">{{$data->pricingPlan->mining->name}}</td>
                                                <td data-label="Status">
                                                    @if($data->status == 1)
                                                        <button class="btn btn-success btn-sm">
                                                            Active
                                                        </button>
                                                    @elseif($data->status == -1)
                                                        <button class="btn btn-warning btn-sm">
                                                            Expired
                                                        </button>
                                                    @endif
                                                </td>
                                                <td data-label="Time">{!! date(' d F, Y h:s A', strtotime($data->end_time)) !!} </td>
                                            </tr>
                                            <tr>
                                                <td colspan="9" class="td-separator">
                                                    <span class="separator"></span>
                                                </td>
                                            </tr>
                                        @endforeach

                                    @else
                                        <tr>
                                            <td colspan="9"> You don't have any plan purchase  history !!</td>
                                        </tr>

                                        <tr>
                                            <td colspan="9" class="td-separator">
                                                <span class="separator"></span>
                                            </td>
                                        </tr>
                                    @endif


                                    </tbody>
                                </table>

                                {{ $myPlan->links('partials.pagination') }}
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop