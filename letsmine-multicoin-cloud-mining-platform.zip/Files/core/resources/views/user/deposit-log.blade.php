@extends('user')
@section('content')
    @include('partials.breadcrumb')

    <div class="transaction">
        <div class="container">


            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="transaction-area">

                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="deposit" role="tabpanel" aria-labelledby="home-tab">

                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Trx</th>
                                        <th scope="col">Details</th>
                                        <th scope="col">Amount</th>
                                        <th scope="col">Time</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @if(count($invests) >0)
                                        @foreach($invests as $k=>$data)
                                            <tr>
                                                <td data-label="SL">{{++$k}}</td>
                                                <td data-label="#Trx">{{$data->trx or 'N/A'}}</td>
                                                <td data-label="Details">{!! $data->gateway->name  or 'N/A' !!}</td>
                                                <td data-label="Amount">{!! $data->amount  or 'N/A' !!} {!! $basic->currency !!}</td>
                                                <td data-label="Time">
                                                    {!! date(' d M, Y h:s A', strtotime($data->created_at)) !!}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5" class="td-separator">
                                                    <span class="separator"></span>
                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="5"> You don't have any deposit history !!</td>
                                        </tr>

                                        <tr>
                                            <td colspan="5" class="td-separator">
                                                <span class="separator"></span>
                                            </td>
                                        </tr>
                                    @endif
                                    </tbody>
                                </table>

                                {{ $invests->links('partials.pagination') }}
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop