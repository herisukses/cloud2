@extends('layout')
@section('content')
    @include('partials.breadcrumb')
    <div class="contact login">
        <div class="container">
            @if(Auth::user()->status == 0)
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-6">
                    <div class="section-title text-center">
                        <h2>Your Account Has been Blocked</h2>
                    </div>
                </div>
            </div>
            @endif

                @if(Auth::user()->email_verify == 0 )
            <div class="row">
                <div class="col-xl-6 col-lg-6">
                    <form class="contact-form"  method="POST" action="{{route('user.send-emailVcode') }}" >
                        @csrf
                        <input type="hidden" name="id" value="{{Auth::user()->id}}">

                        <div class="row">
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label for="InputName">Your E-mail Address<span class="requred">*</span></label>
                                    <input type="text" class="form-control" id="InputName" value="{{Auth::user()->email}}" readonly required>

                                </div>
                            </div>

                            <div class="col-xl-12 col-lg-12">
                                <div class="row d-flex">
                                    <div class="col-xl-6 col-lg-6">
                                        <button type="submit" class="login-button">Send Code</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="col-xl-6 col-lg-6">
                    <form class="contact-form"  method="POST" action="{{ route('user.email-verify')}}" >
                        @csrf
                        <input type="hidden" name="id" value="{{Auth::user()->id}}">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label for="InputName">Enter Verification Code<span class="requred">*</span></label>
                                    <input type="text" name="email_code"  class="form-control" id="InputName" placeholder="Verification Code" required>
                                </div>
                            </div>


                            <div class="col-xl-12 col-lg-12">
                                <div class="row d-flex">
                                    <div class="col-xl-6 col-lg-6">
                                        <button type="submit" class="login-button">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

                @elseif(Auth::user()->phone_verify == 0)

                    <div class="row">
                        <div class="col-xl-6 col-lg-6">
                            <form class="contact-form"  method="POST" action="{{route('user.send-vcode') }}" >
                                @csrf
                                <input type="hidden" name="id" value="{{Auth::user()->id}}">

                                <div class="row">
                                    <div class="col-xl-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="InputName">Your Mobile No<span class="requred">*</span></label>
                                            <input type="text" class="form-control" id="InputName" value="{{Auth::user()->phone}}" readonly required>

                                        </div>
                                    </div>

                                    <div class="col-xl-12 col-lg-12">
                                        <div class="row d-flex">
                                            <div class="col-xl-6 col-lg-6">
                                                <button type="submit" class="login-button">Send Code</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div class="col-xl-6 col-lg-6">
                            <form class="contact-form"  method="POST" action="{{ route('user.sms-verify')}}">
                                @csrf
                                <input type="hidden" name="id" value="{{Auth::user()->id}}">
                                <div class="row">
                                    <div class="col-xl-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="InputName">Enter Verification Code<span class="requred">*</span></label>
                                            <input type="text" name="sms_code"  class="form-control" id="InputName" placeholder="Verification Code" required>
                                        </div>
                                    </div>


                                    <div class="col-xl-12 col-lg-12">
                                        <div class="row d-flex">
                                            <div class="col-xl-6 col-lg-6">
                                                <button type="submit" class="login-button">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                @endif

        </div>
    </div>
    <!-- login end -->

@stop