@extends('user')
@section('content')
@include('partials.breadcrumb')

<div class="price">
    <div class="container">


        <div class="row">

            <div class="col-xl-12 col-lg-12">

                <div class="tab-content" id="myTabContent2">
                    <div class="tab-pane fade show active" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
                        <div class="row">

                            <div class="col-md-6 offset-md-3">
                                @include('partials.flash-msg')

                                <div class="single-price">
                                    <form class="contact-form" method="POST" action="{{route('deposit.confirm')}}">
                                        {{csrf_field()}}
                                    <div class="part-bottom">
                                        <ul>
                                            <li class="list-group-item text-color">
                                                <img src="{{asset('assets/images/gateway')}}/{{$data->gateway_id}}.jpg" style="max-width:100px; max-height:100px; margin:0 auto;"/>
                                            </li>
                                            <li class="list-group-item text-color"> Amount : {{$data->amount}}
                                                <strong>{{$basic->currency}}</strong>
                                            </li>



                                            <li class="list-group-item text-color"> Charge : <strong>{{$data->charge}} </strong>{{ $basic->currency }}</li>
                                            <li class="list-group-item text-color"> Payable :
                                                <strong>{{$data->charge + $data->amount}} </strong>{{ $basic->currency }}</li>


                                            <li class="list-group-item text-color"> In USD :
                                                <strong>${{$data->usd}}</strong>
                                            </li>
                                        </ul>

                                        <div class="card-footer">
                                            <button type="submit" class="btn btn-primary custom-btn btn-lg btn-block" >Pay Now</button>
                                        </div>


                                    </div>
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>


@stop