@extends('user')
@section('content')
	@include('partials.breadcrumb')
	<section class="price">
	<div class="container">
		<div class="row">
			<div class="col-md-8 offset-md-2">
				
				<div class="card">
					<div class="card-body text-center">
							<h6 class="text-color"> PLEASE SEND EXACTLY <span style="color: green"> {{ $bcoin }}</span> LiteCoin</h6>
							<h5>TO <span style="color: green"> {{ $wallet}}</span></h5>
							{!! $qrurl !!}
							<h4 class="text-color" style="font-weight:bold;" >SCAN TO SEND</h4>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>



@endsection