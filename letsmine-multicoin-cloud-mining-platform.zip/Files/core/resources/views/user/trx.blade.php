@extends('user')
@section('content')
    @include('partials.breadcrumb')


    <div class="transaction">
        <div class="container">


            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="transaction-area">

                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="deposit" role="tabpanel" aria-labelledby="home-tab">

                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Transaction ID</th>
                                        <th scope="col">Details</th>
                                        <th scope="col">Amount</th>
                                        <th scope="col">Remaining Balance</th>
                                        <th scope="col">Time</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @if(count($invests) >0)
                                        @foreach($invests as $k=>$data)
                                            <tr @if($data->type == '+') class="success"
                                                @elseif($data->type == '-') class="danger" @endif>
                                                <td data-label="SL">{{++$k}}</td>
                                                <td data-label="#TRX">{{$data->trx or 'N/A'}}</td>
                                                <td data-label="Details">{!! $data->title  or 'N/A' !!}</td>
                                                <td data-label="Amount">{!! $data->amount  or 'N/A' !!} @if($data->mining_id == null)  {!! $basic->currency !!} @else  {!! $data->mining->coin_code !!} @endif</td>
                                                <td data-label="Remaining Balance">{!! $data->main_amo  or 'N/A' !!} @if($data->mining_id == null)  {!! $basic->currency !!} @else  {!! $data->mining->coin_code !!} @endif</td>
                                                <td data-label="Time">
                                                    {!! date(' d M, Y h:s A', strtotime($data->created_at)) !!} </td>
                                            </tr>

                                            <tr>
                                                <td colspan="6" class="td-separator">
                                                    <span class="separator"></span>
                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="6"> You don't have any transaction history !!</td>
                                        </tr>

                                        <tr>
                                            <td colspan="6" class="td-separator">
                                                <span class="separator"></span>
                                            </td>
                                        </tr>
                                    @endif
                                    </tbody>
                                </table>

                                {{ $invests->links('partials.pagination') }}
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@stop