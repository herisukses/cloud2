@extends('user')
@section('content')
    @include('partials.breadcrumb')

    <div class="price">
        <div class="container">

            <div class="row">
                @include('errors.error')

                <div class="col-xl-12 col-lg-12">

                    <div class="tab-content" id="myTabContent2">
                        <div class="tab-pane fade show active" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
                            <div class="row">

                                @foreach($withdrawMethod as $gate)
                                    <div class="col-xl-4 col-lg-4 col-md-6">
                                        <div class="single-price special">
                                            <div class="part-top">
                                                <h4>{{$gate->mining->coin_code}} WITHDRAW</h4>
                                            </div>
                                            <div class="part-bottom">
                                                <ul>
                                                    <li> Wallet - {{$gate->wallet_acc}}</li>
                                                    <li> Current Balance
                                                        - {{round($gate->balance, $basic->decimal)}} {{$gate->mining->coin_code}}</li>
                                                    <li> Charge - {{$basic->withdraw_charge}}%</li>
                                                </ul>
                                                <a data-toggle="modal"
                                                   data-target="#withdrawModal{{$gate->id}}" class="white boxed-btn btn-rounded">Select</a>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="depositModal{{$gate->id}}" class="modal fade" role="dialog">
                                        <div class="modal-dialog">

                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Deposit via <strong>{{$gate->name}}</strong></h4>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                </div>

                                                <form method="post" action="{{route('deposit.data-insert')}}">
                                                    <div class="modal-body">
                                                        {{csrf_field()}}

                                                        <input type="hidden" name="gateway" value="{{$gate->id}}">
                                                        <label class="col-md-12 modal-msg-heading"><strong>DEPOSIT AMOUNT</strong>
                                                            <span class="modal-msg">({{ $gate->minamo }} - {{$gate->maxamo }}) {{$basic->currency}}
                                                                <br>
                                                Charged {{ $gate->fixed_charge }} {{$basic->currency}} + {{ $gate->percent_charge }}
                                                                %</span>
                                                        </label>
                                                        <hr/>
                                                        <div class="form-group">
                                                            <div class="input-group">
                                                                <input type="text" name="amount" class="form-control input-lg" id="amount"
                                                                       placeholder=" Enter Amount" required>
                                                                <div class="input-group-prepend">
                                                                    <span class="input-group-text">{{$basic->currency}}</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary ">Preview</button>

                                                        <button type="button" class="btn btn-default " data-dismiss="modal">Close
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>

                                        </div>
                                    </div>

                                    <div id="withdrawModal{{$gate->id}}" class="modal fade" role="dialog">
                                        <div class="modal-dialog">

                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Withdraw via
                                                        <strong>{{$gate->mining->coin_code}}</strong></h4>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                </div>
                                                <div class="modal-body">
                                                    <form method="POST" action="{{route('withdraw.preview') }}">
                                                        {{csrf_field()}}
                                                        <input type="hidden" name="wallet_id" value="{{$gate->id}}">
                                                        <code>Withdraw Charge {{$basic->withdraw_charge}}%</code>
                                                        <hr/>
                                                        <div class="form-group">
                                                            <div class="input-group">
                                                                <input type="text" name="amount" class="form-control" id="amount"
                                                                       required>
                                                                <div class="input-group-prepend">
                                                        <span class="input-group-text"
                                                              id="basic-addon1">{{$gate->mining->coin_code}} </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <button type="submit" class="btn btn-primary btn-block">
                                                                Preview
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                @endforeach

                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>



@stop