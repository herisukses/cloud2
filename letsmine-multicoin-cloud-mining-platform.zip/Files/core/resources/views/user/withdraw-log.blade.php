@extends('user')
@section('content')
    @include('partials.breadcrumb')
    <div class="transaction">
        <div class="container">


            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="transaction-area">

                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="deposit" role="tabpanel" aria-labelledby="home-tab">

                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Trx</th>
                                        <th scope="col">Method</th>
                                        <th scope="col">Amount</th>
                                        <th scope="col">Charge</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Time</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @if(count($invests) >0)
                                        @foreach($invests as $k=>$data)
                                            <tr>
                                                <td data-label="SL">{{++$k}}</td>
                                                <td data-label="#Trx">{{$data->transaction_id or 'N/A'}}</td>
                                                <td data-label="Method">{!! $data->wallet->mining->name  or '' !!}</td>
                                                <td data-label="Amount">{!!  number_format($data->amount, $basic->decimal)  !!} {!! $data->wallet->mining->coin_code !!}</td>
                                                <td data-label="Charge">{!! number_format($data->charge, $basic->decimal) !!} {!! $data->wallet->mining->coin_code !!}</td>
                                                <td data-label="Status">
                                                    @if($data->status == 1)
                                                        <button class="btn btn-primary btn-sm">
                                                            Pending
                                                        </button>
                                                    @elseif($data->status == 2)
                                                        <button class="btn btn-success btn-sm">
                                                            Approved
                                                        </button>
                                                    @elseif($data->status == 3)
                                                        <button class="btn btn-warning btn-sm">
                                                            Refunded
                                                        </button>
                                                    @endif
                                                </td>
                                                <td data-label="Time">
                                                    {!! date(' d M, Y h:s A', strtotime($data->created_at)) !!}</td>
                                            </tr>
                                            <tr>
                                                <td colspan="7" class="td-separator">
                                                    <span class="separator"></span>
                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="7"> You don't have any withdraw  history !!</td>
                                        </tr>

                                        <tr>
                                            <td colspan="7" class="td-separator">
                                                <span class="separator"></span>
                                            </td>
                                        </tr>
                                    @endif
                                    </tbody>
                                </table>

                                {{ $invests->links('partials.pagination') }}
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@stop