@extends('user')
@section('content')
    @include('partials.breadcrumb')
    <div class="contact login">
        <div class="container">

            <div class="row  justify-content-center">
                        <div class="col-xl-6 col-lg-6">
                            <form class="contact-form"  action="" method="post" role="form">
                                @csrf
                                <div class="row">
                                    <div class="col-xl-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="InputName">Current Password<span class="requred">*</span></label>
                                            <input  class="form-control"  type="password" name="current_password"  placeholder="Current Password" required>


                                            @if ($errors->has('current_password'))
                                                <span class="error form-error-msg ">
                                                    <strong>{{ $errors->first('current_password') }}</strong>
                                                </span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-xl-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="InputName">New Password<span class="requred">*</span></label>
                                            <input  class="form-control" type="password" name="password" placeholder="New Password" required>
                                            @if ($errors->has('password'))
                                                <span class="error form-error-msg ">
                                                    <strong>{{ $errors->first('password') }}</strong>
                                                </span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-xl-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="InputName">Confirm Password<span class="requred">*</span></label>
                                            <input  class="form-control" type="password" name="password_confirmation" placeholder="Confirm Password" required>
                                            @if ($errors->has('password_confirmation'))
                                                <span class="error form-error-msg ">
                                                    <strong>{{ $errors->first('password_confirmation') }}</strong>
                                                </span>
                                            @endif
                                        </div>
                                    </div>




                                    <div class="col-xl-12 col-lg-12">
                                        <div class="row d-flex">
                                            <div class="col-xl-6 col-lg-6">
                                                <button type="submit" class="login-button btn-block">Change Password</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

        </div>
    </div>


@endsection

@section('script')
    @if (session('message'))
        <script type="text/javascript">
            $(document).ready(function () {
                swal("Success!", "{{ session('message') }}", "success");
            });
        </script>
    @endif

    @if (session('alert'))
        <script type="text/javascript">
            $(document).ready(function () {
                swal("Sorry!", "{{ session('alert') }}", "error");
            });
        </script>
    @endif
@endsection
