@extends('user')
@section('content')
    @include('partials.breadcrumb')

    <!-- price begin-->
    <div class="price">
        <div class="container">


            <div class="row">

                <div class="col-xl-12 col-lg-12">

                    <div class="tab-content" id="myTabContent2">
                        <div class="tab-pane fade show active" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
                            <div class="row">

                                <div class="col-md-6 offset-md-3">
                                    <div class="single-price">
                                        <div class="part-top">
                                            <h4>{{$plan->title}} {{$page_title}}</h4>
                                        </div>
                                        <div class="part-bottom">
                                            <ul>
                                                <li>Current Balance
                                                    : {{Auth::user()->balance}} {{$basic->currency}}
                                                    <strong></strong>
                                                </li>
                                                <li>
                                                    Purchasing {{$totalPlan}}  {{$plan->unit->name}}
                                                    <strong></strong>
                                                </li>
                                                <li>
                                                    Total Plan Price: {{$plan->rate}} * {{$totalPlan}}
                                                    = {{number_format($totalPrice, $basic->decimal)}}  {{$basic->currency}}
                                                    <strong></strong>
                                                </li>
                                                <li>
                                                    Remaining Balance: {{$remainBalance}} {{$basic->currency}}
                                                    <strong></strong>
                                                </li>
                                                <li>24/7Support</li>
                                            </ul>

                                            <form method="post" action="{{route('confirmPurchase')}}">
                                                {{ csrf_field() }}
                                                <div class="row">
                                                    <input type="hidden" name="total_plan" value="{{$totalPlan}}">
                                                    <input type="hidden" name="user_id" value="{{$user_id}}">
                                                    <input type="hidden" name="rate" value="{{$rate}}">
                                                    <input type="hidden" name="pricing_plan_id" value="{{$pricing_plan_id}}">
                                                    <input type="hidden" name="mining_id" value="{{$mining_id}}">

                                                    <div class="col-md-12">
                                                        <br>
                                                        <button type="submit" class="btn btn-primary btn-lg bold uppercase btn-block">
                                                            <i class="fa fa-send"></i> Confirm Purchase
                                                        </button>

                                                    </div>
                                                </div>

                                            </form>



                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- price end -->
@stop