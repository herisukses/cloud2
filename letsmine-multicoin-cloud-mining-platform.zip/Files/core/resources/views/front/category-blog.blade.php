@extends('layout')
@section('content')
    @include('partials.breadcrumb')


    <!-- blog post begin-->
    <div class="blog-post">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-8">
                    <div class="section-title text-center">
                        <h2 class="extra-margin">Latest<span> Blog Posts</span></h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-8 col-lg-8">
                    <div class="row">

                        @foreach($posts as $k=>$post)
                        <div class="col-xl-6 col-lg-6 col-md-6">
                            <div class="single-blog">
                                <div class="part-img">
                                    <img src="{{asset('assets/images/post/'.$post->image)}}" alt="">
                                </div>
                                @php
                                    $k++;
                                    $slug  = str_slug($post->title);
                                @endphp


                                <div class="part-text">
                                    <h3><a href="{{url('details/'.$post->id.'/'.$slug)}}">{!! $post->title !!}</a></h3>
                                    <h4>
                                        <span class="admin">By Admin </span>.
                                        <span class="date">{{$post->created_at->format('d F Y')}}  </span>.
                                        <span class="category">{!! $post->title !!} </span>
                                    </h4>
                                    <p>{!!  str_limit($post->details, 700);!!}</p>
                                    <a class="read-more" href="{{url('details/'.$post->id.'/'.$slug)}}"><span><i class="fas fa-book-reader"></i></span> Read More</a>
                                </div>
                            </div>
                        </div>
                            @if($k%2 == 0)
                                <div class="col-md-12">
                                {!!  show_add(2)!!}
                                    <br>
                                </div>
                            @endif
                        @endforeach

                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-12">

                    <div class="sidebar">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-6">
                                @include('partials.category')
                            </div>

                            <div class="col-xl-12 col-lg-12 col-md-6">
                                @include('partials.popular-post')
                            </div>

                        </div>
                    </div>

                </div>
            </div>


        </div>
    </div>
    <!-- blog post end -->
@stop