@extends('layout')

@section('content')
    @include('partials.breadcrumb')
    <!-- blog post begin-->
    <div class="blog-post single-blog-post">
        <div class="container">
            <div class="row">

                <div class="col-xl-8 col-lg-8">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12">
                            <div class="single-blog blog-details">
                                <div class="post-shadow">
                                    <div class="part-img">
                                        <img src="{{asset('assets/images/post/'.$post->image)}}" alt="{{$post->title}}">
                                    </div>
                                    <div class="part-text">
                                        @php $catSlug =  str_slug($post->category->name); @endphp

                                        <h3>{{$post->title}}</h3>

                                        <h4>
                                            <span class="admin">By Admin </span>.
                                            <span class="date">{{date('m F, Y',strtotime($post->created_at))}} </span>.
                                            <span class="category"> <a href="{{route('cats.blog',[$post->category->id,$catSlug])}}">{{$post->category->name}} </a></span>
                                        </h4>
                                        <p> {!! $post->details !!}</p>

                                    </div>
                                </div>

                                <div class="comment-area">
                                    <div class="fb-comments" data-colorscheme="dark"  data-width="100%" data-href="{{url()->current()}}"
                                         data-numposts="5"></div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4">
                    <div class="sidebar">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-6">
                                @include('partials.category')
                            </div>

                            <div class="col-xl-12 col-lg-12 col-md-6">
                                {!!  show_add(1)!!}
                            </div>

                            <div class="col-xl-12 col-lg-12 col-md-6">
                                @include('partials.popular-post')
                            </div>

                            <div class="col-xl-12 col-lg-12 col-md-6">
                                {!!  show_add(3)!!}
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- blog post end -->
@stop