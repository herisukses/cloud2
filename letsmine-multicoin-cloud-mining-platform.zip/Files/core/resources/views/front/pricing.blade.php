@extends('layout')
@section('css')

@stop
@section('content')
    @include('partials.breadcrumb')

    <!-- price begin-->
    <div class="price">
        <div class="container">


            <div class="row">

                <div class="col-xl-12 col-lg-12">
                    <ul class="nav nav-tabs" id="myTab2" role="tablist">
                        @foreach($mining as $k => $item)
                        <li class="nav-item">
                            <a class="nav-link @if($k == 0) active @endif" id="monthly-tab" data-toggle="tab" href="#monthly{{$item->id}}" role="tab"
                               aria-selected="true">{{$item->name}}</a>
                        </li>
                        @endforeach
                    </ul>
                    <div class="tab-content" id="myTabContent2">

                        @foreach($mining as $k => $item)
                        <div class="tab-pane fade show @if($k==0)show active @endif" id="monthly{{$item->id}}" role="tabpanel" aria-labelledby="monthly-tab">
                            <div class="row">

                                @foreach($plans->where('cat_id', $item->id) as $plan)

                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="single-price">
                                        <div class="part-top">
                                            <h3>{!! $plan->title !!}</h3>
                                            <h4>{!! $basic->currency_sym !!}{!! $plan->rate !!}<br /><span>Per {{$plan->unit->code }}/s</span></h4>
                                        </div>
                                        <div class="part-bottom">
                                            <ul>
                                                <li>For <strong>{{$plan->period}} {{$plan->duration}}s</strong></li>
                                                <li>
                                                    <span class="name">Maintenance Fee
                                                                        <strong>{{$plan->electricity_charge}} {!! $plan->mining->coin_code !!} </strong>(per day)
                                                                    </span>
                                                </li>
                                                @foreach(json_decode($plan->details) as $value)
                                                    <li>{!! $value !!}</li>
                                                @endforeach

                                            </ul>

                                            @if(Auth::user())
                                                <a class="boxed-btn btn-rounded "
                                                   data-toggle="modal"
                                                   data-target="#Modal{{$plan->id}}">
                                                    Purchase now </a>
                                                <div class="modal fade" id="Modal{{$plan->id}}"
                                                     tabindex="-1" role="dialog">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <form role="form"
                                                                  action="{{route('UserPurchasePlan')}}"
                                                                  method="post">
                                                                {{ csrf_field() }}
                                                                <div class="modal-header">
                                                                    <h4 class="modal-title"
                                                                        id="myModalLabel"><i
                                                                                class="fa fa-shopping-cart"></i>
                                                                        Purchase Now </h4>

                                                                    <button type="button"
                                                                            class="close"
                                                                            data-dismiss="modal"
                                                                            aria-hidden="true"><span
                                                                                class="black">X</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <p class="error"> Purchase
                                                                        Limit {{$plan->minimum}}
                                                                        - {{$plan->maximum}} {{$plan->unit->name}}</p>

                                                                    <input type="hidden" name="id"
                                                                           value="{{$plan->id}}">
                                                                    <input type="hidden"
                                                                           name="mining_id"
                                                                           value="{!! $plan->mining->id !!}">
                                                                    <input type="hidden"
                                                                           name="user_id"
                                                                           value="{{Auth::user()->id}}">
                                                                    <input type="hidden" name="rate"
                                                                           value="{!! $plan->rate !!}">

                                                                    <div class="input-group">
                                                                        <input type="text"
                                                                               name="totalPlan"
                                                                               class="form-control input-lg"
                                                                               placeholder=" Enter  Purchase Quantity"
                                                                               required>
                                                                        <div class="input-group-prepend">
                                                                                                <span class="input-group-text"
                                                                                                      id="basic-addon1">{{$plan->unit->name}}</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="submit"
                                                                            class="btn  btn-success ">
                                                                        Yes
                                                                    </button>
                                                                    <button type="button"
                                                                            class="btn btn-default"
                                                                            data-dismiss="modal">
                                                                        close
                                                                    </button>
                                                                </div>
                                                            </form>

                                                        </div>
                                                    </div>
                                                </div>
                                            @else
                                                <a href="{{route('login')}}">Purchase now</a>
                                            @endif

                                        </div>
                                    </div>
                                </div>

                                @endforeach

                            </div>
                        </div>
                        @endforeach

                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- price end -->
@stop