@extends('layout')
@section('content')
@include('partials.breadcrumb')

<!-- contact begin-->
<div class="address-area">
    <div class="container">
        <div class="tsk-contact-info">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="contact-info-item">
                        <div class="icon-bar">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="info-details">
                            <h5>Our Address</h5>
                            <p>{!! $basic->address !!}</p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="contact-info-item">
                        <div class="icon-bar">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="info-details">
                            <h5>Email Address</h5>
                            <a href="mailto:info@example.com">{{$basic->email}}</a>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="contact-info-item">
                        <div class="icon-bar">
                            <i class="fas fa-mobile-alt"></i>
                        </div>
                        <div class="info-details">
                            <h5>Phone Number</h5>
                            <a href="tel:+8801234567890">{{$basic->phone}}</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="contact pt-120px">

    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12">
                <form class="contact-form" action="" method="post" id="get_in_touch">
                    @csrf
                    <div class="row justify-content-center">
                        <div class="col-xl-8 col-lg-8">
                            <div class="section-title text-center">
                                <h2>{{$basic->contact_title}}</h2>
                                <p>{!! $basic->contact_info !!}</p>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-xl-6 col-lg-6">
                            <div class="form-group">
                                <label for="InputName">Name<span class="requred">*</span></label>
                                <input type="text" name="name"  class="form-control" id="name" placeholder="Enter Your Name"
                                       required>
                                @if($errors->has('name'))
                                    <span class="error form-error-msg">{{ $errors->first('name')}}</span>
                                @endif
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6">
                            <div class="form-group">
                                <label for="InputMail">E-mail<span class="requred">*</span></label>
                                <input type="email" name="email" class="form-control" id="email" id="InputMail" placeholder="Enter Your E-mail Address"
                                       required>
                                @if($errors->has('email'))
                                    <span class="error form-error-msg">{{ $errors->first('email')}}</span>
                                @endif
                            </div>
                        </div>

                        <div class="col-xl-12 col-lg-12">
                            <div class="form-group">
                                <label for="exampleFormControlTextarea1">Meassage<span class="requred">*</span></label>
                                <textarea name="message"  class="form-control" id="message" rows="3" placeholder="Enter Your Meassage"
                                          required></textarea>
                                @if($errors->has('message'))
                                    <span class="error form-error-msg">{{ $errors->first('message')}}</span>
                                @endif
                            </div>
                        </div>
                        <div class="col-xl-12 col-lg-12">
                            <button type="submit">Send Now</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="google-map" id="map"></div>

</div>
<!-- contact end -->

@stop