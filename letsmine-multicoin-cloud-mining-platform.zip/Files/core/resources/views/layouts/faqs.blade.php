@extends('layout')
@section('content')
@include('partials.breadcrumb')
    <!-- faq begin-->
    <div class="faq">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-6">
                    <div class="section-title text-center">
                        <h2>Frequently Questions</h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="accordion" id="accordionExample">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12">

                                @foreach($faqs as $k => $f)
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                                    data-target="#collapseOne{{$f->id}}" aria-expanded="false" aria-controls="collapseOne{{$f->id}}">
                                                {{$f->title}}
                                            </button>
                                        </h5>
                                    </div>
                                    <div id="collapseOne{{$f->id}}" class="collapse @if($k == 0) show @endif" data-parent="#accordionExample">
                                        <div class="card-body">
                                            {!!  $f->description !!}
                                        </div>
                                    </div>
                                </div>
                                @endforeach

                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- faq end -->
@stop