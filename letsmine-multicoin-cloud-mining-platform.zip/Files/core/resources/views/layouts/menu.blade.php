@extends('layout')
@section('content')

  @include('partials.breadcrumb')
  <!-- we are begin -->
  <div class="we-re">
      <div class="container">
          <div class="row d-flex">
              <div class="col-xl-12 col-lg-12 d-flex align-items-center">
                  <div class="part-text">
                      <div class="section-title">
                          <h2>Make A Deal With Us For Business!</h2>
                          <p> {!! $menu->description !!}</p>
                      </div>
                  </div>
              </div>

          </div>
      </div>
  </div>
  <!-- we are end -->

@stop