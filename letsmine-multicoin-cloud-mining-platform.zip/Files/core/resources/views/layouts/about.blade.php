@extends('layout')
@section('content')

    @include('partials.breadcrumb')

    <!-- we are begin -->
    <div class="we-re">
        <div class="container">
            <div class="row d-flex">
                <div class="col-xl-6 col-lg-6 d-flex align-items-center">
                    <div class="part-text">
                        <div class="section-title">
                            <h2>{!! $integrationStep1->val1 !!}</h2>
                            <p>{!! $integrationStep1->val2 !!}</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6">
                    <div class="part-img">
                        <img src="{{asset('assets/images/about-video-image.jpg')}}" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- we are end -->
    <!-- video begin-->
    <div class="video">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-8">
                    <div class="section-title">
                        <h2>Our Overview</h2>
                        <p>We bring the right people together to challenge established thinking and drive transformation.
                            We will show the way to successive.</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-6">
                    <div class="play-video">
                        <a class="play-button venobox mfp-iframe" href="{{$basic->about_video}}"><i class="fas fa-play"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- video end -->

    <div class="we-re">
        <div class="container">
            <div class="row d-flex">
                <div class="col-xl-12 col-lg-12 d-flex align-items-center">
                    <div class="part-text">
                        <div class="section-title">
                            <p>{!! $basic->about!!}</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
@stop