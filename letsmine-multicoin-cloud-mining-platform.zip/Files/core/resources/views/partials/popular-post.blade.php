@if(count($popular) >0)
    <div class="widget widget-popular-post">
        <h6 class="widgettitle">
            <span>Popular Posts</span>
        </h6>
        @foreach($popular as $data)
            @php
                $slug = str_slug($data->title)
            @endphp
        <div class="single-post">
            <div class="part-img">
                <img src="{{asset('assets/images/post/'.$data->image)}}" alt="">
            </div>
            <div class="part-text">
                <h4><a href="{{route('blog.details',[$data->id,$slug])}}">{{str_limit($data->title,30)}}</a></h4>
                <h5>{{$data->created_at->format('d F, Y')}}</h5>
            </div>
        </div>
        @endforeach
    </div>
@endif
