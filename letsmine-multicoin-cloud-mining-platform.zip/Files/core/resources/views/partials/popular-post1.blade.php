@if(count($popular) >0)
    <div class="widget-area latest-post"><!-- latest post widget start -->
        <div class="widget-title">
            <h4>Popular Posts</h4>
        </div>
        <div class="widget-body"><!-- widget body -->
            @foreach($popular as $data)
                <div class="single-latest-post"><!-- single lates post item start-->
                    <div class="media"><!-- media  -->
                        <img class="mr-3 img-40" src="{{asset('assets/images/post/'.$data->image)}}"
                             alt="latest blog post image">
                        <div class="media-body"><!-- media body-->
                            @php
                                $slug = str_slug($data->title)
                            @endphp
                            <a href="{{url('details/'.$data->id.'/'.$slug)}}">
                                <h5 class="mt-0">{{str_limit($data->title,40)}}</h5>
                            </a>
                            <span class="meta-time"><i
                                        class="far fa-clock"></i> {{$data->created_at->diffForHumans()}}</span>
                        </div><!-- /.media body -->
                    </div><!-- /.media -->
                </div>
                <!-- single lates post item start-->
            @endforeach
        </div><!-- /. widget body -->
    </div><!-- latest post widget end
@endif
