
@if(count($categories) >0)
    <div class="widget widget_categories">
        <h6 class="widgettitle"><span>Categories</span></h6>

        <ul>
            @foreach($categories as $category)
                @php
                    $slug = str_slug($category->name)
                @endphp
                <li><a href="{{url('cats/'.$category->id.'/'.$slug)}}">{!! $category->name !!} <span
                                class="count">({!! $category->posts()->count() !!}
                            )</span></a></li>
            @endforeach
        </ul>
    </div>
@endif