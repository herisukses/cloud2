@extends('layout')
@section('content')
    @include('partials.breadcrumb')
    <!-- register begin-->
    <div class="contact register">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-7 col-lg-7">
                    <div class="section-title text-center">
                        <h2>Signup to <span>Create New Account</span></h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    @if($basic->registration == 1)
                    <form class="contact-form" method="POST" action="{{ route('register') }}">
                        @csrf
                        <div class="row">
                            <div class="col-xl-6 col-lg-6">
                                <div class="form-group">
                                    <label for="InputFirstname">Full Name<span class="requred">*</span></label>
                                    <input type="text" class="form-control" id="InputFirstname" name="name" placeholder="Enter Your Name"
                                           required>
                                    @if ($errors->has('name'))
                                        <span class="error form-error-msg ">
                                                <strong>{{ $errors->first('name') }}</strong>
                                            </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <div class="form-group">
                                    <label for="InputLastname">Username<span class="requred">*</span></label>
                                    <input type="text" name="username"  class="form-control" id="InputLastname" placeholder="Enter Your Username"
                                           required>
                                    @if ($errors->has('username'))
                                        <span class="error form-error-msg ">
                                                <strong>{{ $errors->first('username') }}</strong>
                                            </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <div class="form-group">
                                    <label for="InputMail">E-mail<span class="requred">*</span></label>
                                    <input type="email" name="email" class="form-control" id="InputMail" placeholder="Enter Your E-mail"
                                           required>
                                    @if ($errors->has('email'))
                                        <span class="error form-error-msg ">
                                                <strong>{{ $errors->first('email') }}</strong>
                                            </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <div class="form-group">
                                    <label for="InputUsername">Phone<span class="requred">*</span></label>
                                    <input type="text" name="phone" class="form-control" id="InputUsername" placeholder="Enter Your Conatct Number"
                                           required>
                                    @if ($errors->has('phone'))
                                        <span class="error form-error-msg ">
                                                <strong>{{ $errors->first('phone') }}</strong>
                                            </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <div class="form-group">
                                    <label for="InputPassword">Password<span class="requred">*</span></label>
                                    <input type="password" name="password" class="form-control" id="InputPassword" placeholder="Enter Your Password"
                                           required>
                                    @if ($errors->has('password'))
                                        <span class="error form-error-msg ">
                                                <strong>{{ $errors->first('password') }}</strong>
                                            </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <div class="form-group">
                                    <label for="InputRetypepassword">Re-type Password<span class="requred">*</span></label>
                                    <input type="password" class="form-control" name="password_confirmation" id="InputRetypepassword" placeholder="Re-type Password"
                                           required>
                                </div>
                            </div>


                            <div class="col-xl-6 col-lg-6">
                                <div class="form-group mb-0 checkbox">
                                    <div class="form-check pl-0">
                                        <span>Already have an account ? <a href="{{route('login')}}"> Sign In</a></span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-6 col-lg-6">
                                <button type="submit" class="submit-button">Sign Up</button>
                            </div>
                        </div>
                    </form>
                    @else
                        <h3 class="text-danger">Registration Has been Closed By Admin</h3>

                    @endif
                </div>
            </div>
        </div>
    </div>
    <!-- register end -->

@endsection
