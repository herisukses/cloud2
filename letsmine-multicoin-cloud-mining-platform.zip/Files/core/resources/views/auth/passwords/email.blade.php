@extends('layout')

@section('content')
    @include('partials.breadcrumb')
    <!-- login begin-->
    <div class="contact login">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-6">
                    <div class="section-title text-center">
                        <h2>Forgot <span>Password</span></h2>

                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-6">
                    <form class="contact-form" method="POST" action="{{ route('user.password.email') }}">
                        @csrf
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label for="InputAmount">E-mail<span class="requred">*</span></label>
                                    <input type="email" class="form-control" name="email" id="InputAmount" placeholder="Enter Your E-mail Address"
                                           required>
                                </div>
                            </div>


                            <div class="col-xl-12 col-lg-12">
                                <div class="row d-flex">
                                    <div class="col-xl-6 col-lg-6">
                                        <button type="submit" class="login-button">Forgot Password</button>
                                    </div>
                                    <div class="col-xl-6 col-lg-6 d-flex align-items-center">
                                        <a href="{{ url('/login') }}" class="forgetting-password">Back To Login</a>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- login end -->


@endsection
