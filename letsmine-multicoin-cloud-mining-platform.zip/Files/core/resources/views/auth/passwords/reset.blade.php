@extends('layout')

@section('content')
    @include('partials.breadcrumb')

    <div class="contact login">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-6">
                    <div class="section-title text-center">
                        <h2>Reset <span>Password</span></h2>

                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-6">
                    @include('errors.error')
                    @if (session()->has('message'))
                        <div class="alert alert-{{ session()->get('type') }} alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;
                            </button>
                            {{ session()->get('message') }}
                        </div>
                    @endif
                    @if (session()->has('status'))
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;
                            </button>
                            {{ session()->get('status') }}
                        </div>
                    @endif
                    <br>
                    <form class="contact-form" method="POST" action="{{ route('user.password.request') }}">
                        @csrf
                        <div class="row">

                            <input type="hidden" name="token" value="{{ $token }}">

                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label for="InputAmount">E-mail<span class="requred">*</span></label>
                                    <input type="email" class="form-control" name="email" id="InputAmount" value="{{$email}}" placeholder="Enter Your E-mail Address"
                                           readonly>
                                </div>
                            </div>

                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label for="InputAmount">New Password<span class="requred">*</span></label>
                                    <input type="password" name="password" class="form-control"  id="InputAmount"  placeholder="Password"
                                           readonly>
                                </div>
                            </div>

                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label for="InputAmount">Confirm Password<span class="requred">*</span></label>
                                    <input type="password" name="password_confirmation" class="form-control"  id="InputAmount"  placeholder="Password"
                                           readonly>
                                </div>
                            </div>


                            <div class="col-xl-12 col-lg-12">
                                <div class="row d-flex">
                                    <div class="col-xl-6 col-lg-6">
                                        <button type="submit" class="login-button">Reset Password</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
