@extends('layout')

@section('content')

    @php $page_title = "404 Not Found" @endphp
    @include('partials.breadcrumb')
    <!-- about begin -->
    <div class="about">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-8">
                    <div class="section-title">
                        <h2>Sorry, Page Not Found</h2>
                        <p> <a href="{{url('/')}}"><i class="fas fa-home"></i> Back To Home</a> </p>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- about end -->
@stop