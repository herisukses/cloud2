<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> {{$page_title}} | {{$basic->sitename}} </title>
    <!-- favicon -->
    <link rel="shortcut icon" href="{{asset('assets/images/logo/favicon.png')}}" type="image/x-icon">
    <!-- bootstrap -->
    <link rel="stylesheet" href="{{url('/')}}/assets/front/css/bootstrap.min.css">
    <!-- fontawesome icon  -->
    <link rel="stylesheet" href="{{url('/')}}/assets/front/css/fontawesome.min.css">
    <!-- flaticon css -->
    <link rel="stylesheet" href="{{url('/')}}/assets/front/fonts/flaticon.css">
    <!-- animate.css -->
    <link rel="stylesheet" href="{{url('/')}}/assets/front/css/animate.css">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="{{url('/')}}/assets/front/css/owl.carousel.min.css">
    <!-- magnific popup -->
    <link rel="stylesheet" href="{{url('/')}}/assets/front/css/magnific-popup.css">
    <!-- stylesheet -->
    <link rel="stylesheet" href="{{url('/')}}/assets/front/css/style.css">
    <!-- responsive -->
    <link rel="stylesheet" href="{{url('/')}}/assets/front/css/responsive.css">

    <link href="{{asset('assets/front/css/sweetalert.css')}}" rel="stylesheet" />
    <link href="{{asset('assets/front/css/toastr.min.css')}}" rel="stylesheet" />
    @yield('css')

    <link rel="stylesheet" href="{{asset('assets/front/css/style.php')}}?color={{ $basic->color }}">
</head>

<body>
{!! $basic->fb_comment !!}
<!-- preloader begin-->
<div class="preloader">
    <div class='loader'>
        <div class='loader--dot'></div>
        <div class='loader--dot'></div>
        <div class='loader--dot'></div>
        <div class='loader--dot'></div>
        <div class='loader--dot'></div>
        <div class='loader--dot'></div>
        <div class='loader--text'></div>
    </div>
</div>
<!-- preloader end -->

<!-- header begin-->
<header class="header">

    <div class="header-bottom">
        <div class="container">
            <div class="row d-flex">
                <div class="col-xl-2 col-lg-2 col-12 d-block d-xl-flex d-lg-flex align-items-center">
                    <div class="mobile-special">
                        <div class="row d-flex">
                            <div class="col-6 col-xl-12 col-lg-12 d-flex align-items-center">
                                <div class="logo">
                                    <a href="{{url('/')}}">
                                        <img src="{{asset('assets/images/logo/logo.png')}}" alt="logo">
                                    </a>
                                </div>
                            </div>
                            <div class="col-6 d-block d-xl-none d-lg-none">
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon"><i class="fas fa-bars"></i></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-7">
                    <div class="mainmenu">
                        <nav class="navbar navbar-expand-lg">

                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav mr-auto justify-content-center">
                                    <li class="nav-item ">
                                        <a class="nav-link" href="{{url('/')}}">Home </a>
                                    </li>


                                    <li class="nav-item  @if(request()->path() == 'pricing') active @endif">
                                        <a class="nav-link" href="{{route('pricing')}}">Pricing</a>
                                    </li>


                                    <li class="nav-item ">
                                        <a class="nav-link" href="{{route('blog')}}">Blog</a>
                                    </li>

                                    <li class="nav-item  @if(request()->path() == 'faqs') active @endif">
                                        <a class="nav-link" href="{{route('faqs')}}">Faq</a>
                                    </li>

                                    <li class="nav-item  @if(request()->path() == 'contact-us') active @endif">
                                        <a class="nav-link" href="{{route('contact')}}">Contact</a>
                                    </li>
                                    
                                    <div class="pranto-hide">
                                        <li class="nav-item">
                                            <a class="nav-link" href="{{url('/register')}}">Sign Up</a>
                                        </li>
                                        
                                        <li class="nav-item">
                                            <a class="nav-link" href="{{url('/login')}}">Sign In</a>
                                        </li>
                                    </div>

                                    @if(Auth::user())
                                        <li class="nav-item dropdown ">
                                            <a class="nav-link dropdown-toggle" href=""
                                               data-toggle="dropdown"><strong>Hi {{ Auth::user()->username }}</strong></a>
                                            <div class="dropdown-menu">
                                                @if(Auth::user()->email_verify != 0 && Auth::user()->phone_verify != 0)
                                                    <a class="dropdown-item" href="{{route('home')}}">Dashboard</a>
                                                    <a class="dropdown-item" href="{{route('edit-profile')}}">Edit Profile</a>
                                                    <a class="dropdown-item" href="{{route('wallet.settings')}}">Wallet Settings</a>
                                                    <a class="dropdown-item" href="{{route('user.change-password')}}">Change Password</a>
                                                @endif
                                                <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();"> Log Out</a>
                                                <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                                      style="display: none;">
                                                    @csrf
                                                </form>
                                            </div>
                                        </li>
                                    @endif

                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
                @guest
                <div class="col-xl-3 col-lg-3 d-flex align-items-center">
                    <div class="join-us" >
                        <a href="{{route('register')}}">Sign Up</a>
                    </div>
                    &nbsp;
                    &nbsp;
                    &nbsp;
                    &nbsp;

                    <div class="join-us">
                        <a href="{{route('login')}}">Sign In</a>
                    </div>
                </div>
                @endguest
            </div>
        </div>
    </div>
</header>
<!-- header end -->

@yield('content')


<!-- footer begin -->
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="box">
                    <div class="logo text-center">
                        <a href="{{url('/')}}">
                            <img style="max-width: 160px;" src="{{asset('assets/images/logo/logo.png')}}" alt="logo">
                        </a>
                    </div>
                    <p class="text-center">
                        {!! $basic->copyright_text !!}
                    </p>
                    <div class="social_links text-center">
                        <ul>
                            @foreach($social as $data)
                            <li>
                                <a href="{{$data->link}}">
                                    {!! $data->code !!}
                                </a>
                            </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright">
        <p class="text-center">
            {{$basic->copyright}}
        </p>
    </div>
</footer>
<!-- footer end -->

<!-- scroll top button begin -->
<div class="scroll-to-top">
    <a><i class="fas fa-long-arrow-alt-up"></i></a>
</div>
<!-- scroll top button end -->


<!-- jquery -->
<script src="{{url('/')}}/assets/front/js/jquery.js"></script>
<!-- bootstrap -->
<script src="{{url('/')}}/assets/front/js/bootstrap.min.js"></script>
<!-- owl carousel -->
<script src="{{url('/')}}/assets/front/js/owl.carousel.js"></script>
<!-- magnific popup -->
<script src="{{url('/')}}/assets/front/js/jquery.magnific-popup.js"></script>
<!-- way poin js-->
<script src="{{url('/')}}/assets/front/js/waypoints.min.js"></script>
<!-- wow js-->
<script src="{{url('/')}}/assets/front/js/wow.min.js"></script>
<!-- main -->
<script src="{{asset('assets/front/js/sweetalert.js')}}" ></script>
<script src="{{asset('assets/front/js/toastr.min.js')}}" ></script>
<script src="{{url('/')}}/assets/front/js/main.js"></script>

@yield('script')
@if (session('success'))
    <script>
        $(document).ready(function () {
            swal("Success!", "{{ session('success') }}", "success");
        });
    </script>
@endif

@if (session('alert'))
    <script>
        $(document).ready(function () {
            swal("Sorry!", "{{ session('alert') }}", "error");
        });
    </script>
@endif
<script>
            @if(Session::has('message'))
    var type = "{{Session::get('alert-type','info')}}";
    switch (type) {
        case 'info':
            toastr.info("{{Session::get('message')}}");
            break;
        case 'warning':
            toastr.warning("{{Session::get('message')}}");
            break;
        case 'success':
            toastr.success("{{Session::get('message')}}");
            break;
        case 'error':
            toastr.error("{{Session::get('message')}}");
            break;
    }
    @endif
</script>
</body>

</html>