@extends('admin.layout.master')

@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <h3 class="tile-title ">{{$page_title}}
                    <a href="{{route('plan.all')}}" class="btn btn-success btn-md pull-right ">
                        <i class="fa fa-eye"></i> View Plan
                    </a>
                </h3>
                <div class="tile-body">
                    <form role="form" method="POST" action="{{route('plan.update')}}" name="editForm">
                        {{ csrf_field() }}

                        <input type="hidden" name="id" value="{{$plan->id}}">
                        <div class="row">
                            <div class="col-md-4">
                                <h6>Plan Title</h6>
                                <div class="input-group">
                                    <input type="text" class="form-control input-lg" value="{{$plan->title}}"
                                           name="title">
                                    <div class="input-group-append"><span class="input-group-text">
                                            <i class="fa fa-font"></i>
                                            </span>
                                    </div>
                                </div>
                                @if ($errors->has('title'))
                                    <div class="error">{{ $errors->first('title') }}</div>
                                @endif

                            </div>

                            <div class="col-md-4">
                                <h6>Coin</h6>
                                <select name="cat_id" id="cat_id" class="form-control">
                                    <option value="">Select Coin</option>
                                    @foreach($minner as $data)
                                        <option value="{{$data->id}}"
                                                data-code="{{ $data->coin_code }}">{{$data->name}}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('cat_id'))
                                    <div class="error">{{ $errors->first('cat_id') }}</div>
                                @endif
                            </div>
                            <div class="col-md-4">
                                <h6>Unit</h6>
                                <select name="unit_id" id="unit_id" class="form-control">
                                    <option value="">Select Unit</option>
                                    @foreach($units as $unit)
                                        <option value="{{$unit->id}}">{{$unit->name}}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('unit'))
                                    <div class="error">{{ $errors->first('unit') }}</div>
                                @endif
                            </div>
                        </div>
                        <br>

                        <div class="row">
                            <div class="col-md-4">
                                <h6>Rate </h6>
                                <div class="input-group">
                                    <input type="text" class="form-control input-lg" value="{{$plan->rate}}"
                                           name="rate">
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                        {{$basic->currency}}
                                        </span>
                                    </div>
                                </div>
                                @if ($errors->has('rate'))
                                    <div class="error">{{ $errors->first('rate') }}</div>
                                @endif
                            </div>

                            <div class="col-md-4">
                                <h6>Period / Duration </h6>
                                <div class="input-group">
                                    <input type="text" class="form-control input-lg" value="{{$plan->period}}"
                                           name="period">
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                            <select name="duration">
                                                <option value="year">Year</option>
                                                <option value="month">Month</option>
                                                <option value="day">Day</option>
                                            </select>
                                        </span>
                                    </div>
                                </div>
                                @if ($errors->has('period'))
                                    <div class="error">{{ $errors->first('period') }}</div>
                                @endif
                            </div>
                            <div class="col-md-4">
                                <h6>Return Amount (Per Day)</h6>
                                <div class="input-group">
                                    <input type="text" class="form-control" value="{{$plan->return_amount}}"
                                           name="return_amount">
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                            <span class="show_coin_code">{{$plan->mining->coin_code}}</span>
                                         </span>
                                    </div>
                                </div>
                                @if ($errors->has('return_amount'))
                                    <div class="error">{{ $errors->first('return_amount') }}</div>
                                @endif
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-3">
                                <h6>Minimum Purchase </h6>
                                <div class="input-group">
                                    <input type="text" class="form-control input-lg" value="{{$plan->minimum}}"
                                           name="minimum">
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                        Unit
                                        </span>
                                    </div>
                                </div>
                                @if ($errors->has('minimum'))
                                    <div class="error">{{ $errors->first('minimum') }}</div>
                                @endif
                            </div>

                            <div class="col-md-3">
                                <h6>Maximum Purchase </h6>
                                <div class="input-group">
                                    <input type="text" class="form-control input-lg" value="{{$plan->maximum}}"
                                           name="maximum">
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                        Unit
                                        </span>
                                    </div>
                                </div>
                                @if ($errors->has('maximum'))
                                    <div class="error">{{ $errors->first('maximum') }}</div>
                                @endif
                            </div>

                            <div class="col-md-3">
                                <h6>Maintenance Fee (Per Day)</h6>
                                <div class="input-group">
                                    <input type="text" value="{{$plan->electricity_charge}}" class="form-control input-lg"
                                           name="electricity_charge">
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                        <div class="show_coin_code">{{$plan->mining->coin_code}}</div>
                                        </span>
                                    </div>
                                </div>
                                @if ($errors->has('electricity_charge'))
                                    <div class="error">{{ $errors->first('electricity_charge') }}</div>
                                @endif
                            </div>


                            <div class="col-md-3">
                                <h6>Status</h6>
                                <input data-toggle="toggle" data-onstyle="success" data-offstyle="danger"
                                       data-width="100%" type="checkbox"
                                       name="status" {{$plan->status == "1" ? 'checked' : '' }}>
                            </div>

                        </div>
                        <br>

                        <div class="row">
                            <div class="col-md-12">
                                <h6>Details</h6>

                                @php
                                $details = json_decode($plan->details);
                                @endphp
                                <div class="description">
                                    @foreach($details as$val)
                                            <div class="row">
                                                <div class="col-md-12" id="">
                                                    <div class="input-group">
                                                        <input name="details[]" value="{{ $val }}" class="form-control margin-top-10"
                                                               type="text" required placeholder="Plan Description">
                                                        <span class="input-group-btn">
                                                 <button class="btn btn-danger margin-top-10 delete_desc" type="button"><i
                                                             class='fa fa-times'></i></button>
                                                </span>
                                                    </div>
                                                </div>
                                            </div>
                                        <br>
                                    @endforeach
                                    <div id="planDescriptionContainer"></div>

                                    <div class="row">
                                        <div class="col-md-12 text-right margin-top-10">
                                            <button id="btnAddDescription" type="button"
                                                    class="btn btn-sm btn-primary">Add Description
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                @if ($errors->has('details'))
                                    <div class="error">{{ $errors->first('details') }}</div>
                                @endif
                            </div>

                        </div>
                        <br>
                        <div class="row">
                            <br>
                            <div class="col-md-12 ">
                                <button class="btn btn-primary btn-block btn-lg">Update Plan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>

        document.forms['editForm'].elements['duration'].value = "{{$plan->duration}}",
            document.forms['editForm'].elements['cat_id'].value = {{$plan->cat_id}},

            document.forms['editForm'].elements['unit_id'].value = {{$plan->unit_id}}

    </script>
@endsection

@section('script')
    <script>
        (function ($) {
            $(document).ready(function () {
                var code = $('#cat_id option:selected', this).data('code');
                $('#coin_code').text(code);

                $(document).on('change', '#cat_id', function () {
                    let code = $('option:selected', this).data('code');
                    $('.show_coin_code').text(code);
                });
            });
        })(jQuery);
    </script>

    <script>
        var max = 1;
        $(document).ready(function () {
            $("#btnAddDescription").on('click', function () {
                appendPlanDescField($("#planDescriptionContainer"));
            });

            $(document).on('click', '.delete_desc', function () {
                $(this).closest('.input-group').remove();
            });
        });

        function appendPlanDescField(container) {
            max++;
            container.append(
                '<br><div class="input-group">' +
                '<input name="details[]" value="" class="form-control margin-top-10" type="text" required placeholder="Plan Description">\n' +
                '<span class="input-group-btn">'+
                '<button class="btn btn-danger margin-top-10 delete_desc" type="button"><i class="fa fa-times"></i></button>' +
                '</span>' +
                '</div>'
            );
        }
    </script>


@stop