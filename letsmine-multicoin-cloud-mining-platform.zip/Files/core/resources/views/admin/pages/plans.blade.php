@extends('admin.layout.master')

@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <div class="tile-title ">
                    <a href="{{route('plan.create')}}" class="btn btn-success btn-md pull-right ">
                        <i class="fa fa-plus"></i> Add Plan
                    </a>
                    <br>
                </div>
                <div class="tile-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="">
                            <thead>
                            <tr>
                                <th>SL</th>
                                <th> Title</th>
                                <th> Price</th>
                                <th>Unit</th>
                                <th>Coin</th>
                                <th>Status</th>
                                <th>ACTION</th>
                            </tr>
                            </thead>

                            <tbody>

                            @foreach($plans as $k=>$data)
                                <tr>
                                    <td data-label="SL">{{++$k}}</td>
                                    <td data-label="Title">{{$data->title or 'N/A'}}</td>
                                    <td data-label="Rate">{{number_format($data->rate, $basic->decimal)}} {{$basic->currency}}</td>
                                    <td data-label="Unit">{{$data->unit->name or 'N/A'}}</td>
                                    <td data-label="Category">{{$data->mining->name or 'N/A'}}</td>
                                    <td data-label="Status">
                                        <b class="btn btn-sm btn-{{ $data->status ==0 ? 'warning' : 'success' }}">{{ $data->status == 0 ? 'Deactive' : 'Active' }}</b>
                                    </td>
                                    <td data-label="Action">
                                        <a href="{{route('plan.edit',$data->id)}}" class="btn btn-outline-primary btn-sm ">
                                            <i class="fa fa-edit"></i> EDIT
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        {!! $plans->links() !!}
                    </div>

                </div>
            </div>
        </div>
    </div>

@endsection
@section('script')

@endsection