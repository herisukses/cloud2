@extends('admin.layout.master')

@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <h3 class="tile-title">{{$page_title}}</h3>
                <div class="tile-body">
                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover order-column"
                               id="">
                            <thead>
                            <tr>
                                <th> User </th>
                                <th> Transaction  </th>
                                <th> Method </th>
                                <th> Request Amount </th>
                                <th> Total Amount </th>
                                <th> Status </th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($bits as $data)
                                <tr>
                                    <td>
                                        <a href="{{route('user.single',$data->user->id)}}">
                                            {{$data->user->username}}
                                        </a>
                                    </td>
                                    <td>
                                        {{$data->transaction_id}}
                                    </td>
                                    <td> <strong>
                                            {!! $data->wallet->mining->name !!}</strong>
                                    </td>
                                    <td> <strong>
                                            {!! number_format($data->amount, $basic->decimal)  !!} {{$data->wallet->mining->coin_code}}</strong>
                                    </td>
                                    <td> <strong>
                                            {!! number_format($data->net_amount, $basic->decimal)  !!}   {{$data->wallet->mining->coin_code}}</strong>
                                    </td>

                                    <td>
                                        @if($data->status == 2)
                                            <button  class="btn btn-outline-success  btn-sm "> Approved </button>
                                        @elseif($data->status == 1)
                                            <button class="btn btn-outline-warning  btn-sm ">Pending </button>
                                        @elseif($data->status == 3)
                                            <button class="btn btn-outline-danger  btn-sm ">Refund </button>
                                        @endif
                                    </td>
                                </tr>

                            @endforeach
                            <tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection