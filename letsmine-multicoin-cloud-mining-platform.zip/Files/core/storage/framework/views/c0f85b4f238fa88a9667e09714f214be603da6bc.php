<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> <?php echo e($page_title); ?> | <?php echo e($basic->sitename); ?> </title>
    <!-- favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo/favicon.png')); ?>" type="image/x-icon">
    <!-- bootstrap -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/front/css/bootstrap.min.css">
    <!-- fontawesome icon  -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/front/css/fontawesome.min.css">
    <!-- flaticon css -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/front/fonts/flaticon.css">
    <!-- animate.css -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/front/css/animate.css">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/front/css/owl.carousel.min.css">
    <!-- magnific popup -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/front/css/magnific-popup.css">
    <!-- stylesheet -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/front/css/style.css">
    <!-- responsive -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/front/css/responsive.css">

    <link href="<?php echo e(asset('assets/front/css/sweetalert.css')); ?>" rel="stylesheet" />

    <link href="<?php echo e(asset('assets/front/css/toastr.min.css')); ?>" rel="stylesheet" />
    <?php echo $__env->yieldContent('css'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/style.php')); ?>?color=<?php echo e($basic->color); ?>">
</head>

<body>
<?php echo $basic->fb_comment; ?>

<!-- preloader begin-->
<div class="preloader">
    <div class='loader'>
        <div class='loader--dot'></div>
        <div class='loader--dot'></div>
        <div class='loader--dot'></div>
        <div class='loader--dot'></div>
        <div class='loader--dot'></div>
        <div class='loader--dot'></div>
        <div class='loader--text'></div>
    </div>
</div>
<!-- preloader end -->

<!-- header begin-->
<header class="header">

    <div class="header-bottom">
        <div class="container">
            <div class="row d-flex">
                <div class="col-xl-2 col-lg-2 col-12 d-block d-xl-flex d-lg-flex align-items-center">
                    <div class="mobile-special">
                        <div class="row d-flex">
                            <div class="col-6 col-xl-12 col-lg-12 d-flex align-items-center">
                                <div class="logo">
                                    <a href="<?php echo e(url('/')); ?>">
                                        <img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" alt="logo">
                                    </a>
                                </div>
                            </div>
                            <div class="col-6 d-block d-xl-none d-lg-none">
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon"><i class="fas fa-bars"></i></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-10 col-lg-10">
                    <div class="mainmenu">
                        <nav class="navbar navbar-expand-lg">

                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav mr-auto justify-content-center">
                                    <li class="nav-item ">
                                        <a class="nav-link" href="<?php echo e(route('home')); ?>">Dashboard </a>
                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Package</a>
                                        <div class="dropdown-menu">
                                            <a href="<?php echo e(route('pricing')); ?>" class="dropdown-item">All Package</a>
                                            <a href="<?php echo e(route('myPlan.history')); ?>" class="dropdown-item"> Purchase History</a>
                                        </div>
                                    </li>



                                    <li class="nav-item  <?php if(request()->path() == 'user/transaction-log'): ?> active <?php endif; ?>">
                                        <a class="nav-link" href="<?php echo e(route('user.trx')); ?>">Transaction Log</a>
                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#"><strong>Balance <?php echo e(round(Auth::user()->balance , $basic->decimal)); ?> <?php echo e($basic->currency); ?></strong></a>
                                        <div class="dropdown-menu">
                                            <a href="<?php echo e(route('deposit')); ?>" class="dropdown-item">Deposit Fund</a>
                                            <a href="<?php echo e(route('user.depositLog')); ?>" class="dropdown-item">Deposit History</a>
                                        </div>
                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Withdraw</a>
                                        <div class="dropdown-menu">
                                            <a href="<?php echo e(route('withdraw.money')); ?>" class="dropdown-item">Withdraw Fund</a>
                                            <a href="<?php echo e(route('user.withdrawLog')); ?>" class="dropdown-item">Withdraw History</a>
                                        </div>
                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#"><strong>Hi <?php echo e(Auth::user()->username); ?></strong></a>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="<?php echo e(route('edit-profile')); ?>">Edit Profile</a>
                                            <a class="dropdown-item" href="<?php echo e(route('wallet.settings')); ?>">Wallet Settings</a>
                                            <a class="dropdown-item" href="<?php echo e(route('user.change-password')); ?>">Change Password</a>
                                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"> Log Out</a>
                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                  style="display: none;">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </div>
                                    </li>


                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>

            </div>
        </div>
    </div>
</header>
<!-- header end -->

<?php echo $__env->yieldContent('content'); ?>


<!-- footer begin -->
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="box">
                    <div class="logo text-center">
                        <a href="<?php echo e(url('/')); ?>">
                            <img style="max-width: 160px;" src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" alt="logo">
                        </a>
                    </div>
                    <p class="text-center">
                        <?php echo $basic->copyright_text; ?>

                    </p>
                    <div class="social_links text-center">
                        <ul>
                            <?php $__currentLoopData = $social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e($data->link); ?>">
                                        <?php echo $data->code; ?>

                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright">
        <p class="text-center">
            <?php echo e($basic->copyright); ?>

        </p>
    </div>
</footer>
<!-- footer end -->

<!-- scroll top button begin -->
<div class="scroll-to-top">
    <a><i class="fas fa-long-arrow-alt-up"></i></a>
</div>
<!-- scroll top button end -->


<!-- jquery -->
<script src="<?php echo e(url('/')); ?>/assets/front/js/jquery.js"></script>
<!-- bootstrap -->
<script src="<?php echo e(url('/')); ?>/assets/front/js/bootstrap.min.js"></script>
<!-- owl carousel -->
<script src="<?php echo e(url('/')); ?>/assets/front/js/owl.carousel.js"></script>
<!-- magnific popup -->
<script src="<?php echo e(url('/')); ?>/assets/front/js/jquery.magnific-popup.js"></script>
<!-- way poin js-->
<script src="<?php echo e(url('/')); ?>/assets/front/js/waypoints.min.js"></script>
<!-- wow js-->
<script src="<?php echo e(url('/')); ?>/assets/front/js/wow.min.js"></script>
<!-- main -->
<script src="<?php echo e(asset('assets/front/js/sweetalert.js')); ?>" ></script>
<script src="<?php echo e(asset('assets/front/js/toastr.min.js')); ?>" ></script>
<script src="<?php echo e(url('/')); ?>/assets/front/js/main.js"></script>

<?php echo $__env->yieldContent('script'); ?>
<?php if(session('success')): ?>
    <script>
        $(document).ready(function () {
            swal("Success!", "<?php echo e(session('success')); ?>", "success");
        });
    </script>
<?php endif; ?>

<?php if(session('alert')): ?>
    <script>
        $(document).ready(function () {
            swal("Sorry!", "<?php echo e(session('alert')); ?>", "error");
        });
    </script>
<?php endif; ?>
<script>
            <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type','info')); ?>";
    switch (type) {
        case 'info':
            toastr.info("<?php echo e(Session::get('message')); ?>");
            break;
        case 'warning':
            toastr.warning("<?php echo e(Session::get('message')); ?>");
            break;
        case 'success':
            toastr.success("<?php echo e(Session::get('message')); ?>");
            break;
        case 'error':
            toastr.error("<?php echo e(Session::get('message')); ?>");
            break;
    }
    <?php endif; ?>
</script>
</body>

</html>