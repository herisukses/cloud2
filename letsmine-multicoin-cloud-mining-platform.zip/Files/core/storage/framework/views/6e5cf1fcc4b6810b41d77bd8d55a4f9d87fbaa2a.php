<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- price begin-->
    <div class="price">
        <div class="container">


            <div class="row">

                <div class="col-xl-12 col-lg-12">
                    <ul class="nav nav-tabs" id="myTab2" role="tablist">
                        <?php $__currentLoopData = $mining; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <a class="nav-link <?php if($k == 0): ?> active <?php endif; ?>" id="monthly-tab" data-toggle="tab" href="#monthly<?php echo e($item->id); ?>" role="tab"
                               aria-selected="true"><?php echo e($item->name); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="tab-content" id="myTabContent2">

                        <?php $__currentLoopData = $mining; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade show <?php if($k==0): ?>show active <?php endif; ?>" id="monthly<?php echo e($item->id); ?>" role="tabpanel" aria-labelledby="monthly-tab">
                            <div class="row">

                                <?php $__currentLoopData = $plans->where('cat_id', $item->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="single-price">
                                        <div class="part-top">
                                            <h3><?php echo $plan->title; ?></h3>
                                            <h4><?php echo $basic->currency_sym; ?><?php echo $plan->rate; ?><br /><span>Per <?php echo e($plan->unit->code); ?>/s</span></h4>
                                        </div>
                                        <div class="part-bottom">
                                            <ul>
                                                <li>For <strong><?php echo e($plan->period); ?> <?php echo e($plan->duration); ?>s</strong></li>
                                                <li>
                                                    <span class="name">Maintenance Fee
                                                                        <strong><?php echo e($plan->electricity_charge); ?> <?php echo $plan->mining->coin_code; ?> </strong>(per day)
                                                                    </span>
                                                </li>
                                                <?php $__currentLoopData = json_decode($plan->details); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo $value; ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </ul>

                                            <?php if(Auth::user()): ?>
                                                <a class="boxed-btn btn-rounded "
                                                   data-toggle="modal"
                                                   data-target="#Modal<?php echo e($plan->id); ?>">
                                                    Purchase now </a>
                                                <div class="modal fade" id="Modal<?php echo e($plan->id); ?>"
                                                     tabindex="-1" role="dialog">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <form role="form"
                                                                  action="<?php echo e(route('UserPurchasePlan')); ?>"
                                                                  method="post">
                                                                <?php echo e(csrf_field()); ?>

                                                                <div class="modal-header">
                                                                    <h4 class="modal-title"
                                                                        id="myModalLabel"><i
                                                                                class="fa fa-shopping-cart"></i>
                                                                        Purchase Now </h4>

                                                                    <button type="button"
                                                                            class="close"
                                                                            data-dismiss="modal"
                                                                            aria-hidden="true"><span
                                                                                class="black">X</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <p class="error"> Purchase
                                                                        Limit <?php echo e($plan->minimum); ?>

                                                                        - <?php echo e($plan->maximum); ?> <?php echo e($plan->unit->name); ?></p>

                                                                    <input type="hidden" name="id"
                                                                           value="<?php echo e($plan->id); ?>">
                                                                    <input type="hidden"
                                                                           name="mining_id"
                                                                           value="<?php echo $plan->mining->id; ?>">
                                                                    <input type="hidden"
                                                                           name="user_id"
                                                                           value="<?php echo e(Auth::user()->id); ?>">
                                                                    <input type="hidden" name="rate"
                                                                           value="<?php echo $plan->rate; ?>">

                                                                    <div class="input-group">
                                                                        <input type="text"
                                                                               name="totalPlan"
                                                                               class="form-control input-lg"
                                                                               placeholder=" Enter  Purchase Quantity"
                                                                               required>
                                                                        <div class="input-group-prepend">
                                                                                                <span class="input-group-text"
                                                                                                      id="basic-addon1"><?php echo e($plan->unit->name); ?></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="submit"
                                                                            class="btn  btn-success ">
                                                                        Yes
                                                                    </button>
                                                                    <button type="button"
                                                                            class="btn btn-default"
                                                                            data-dismiss="modal">
                                                                        close
                                                                    </button>
                                                                </div>
                                                            </form>

                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('login')); ?>">Purchase now</a>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- price end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>