<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- login begin-->
    <div class="contact login">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-6">
                    <div class="section-title text-center">
                        <h2>Login On <span>Your Account</span></h2>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-6">
                    <form class="contact-form"  method="POST" action="<?php echo e(route('login')); ?>" >
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label for="InputName">Username<span class="requred">*</span></label>
                                    <input type="text" name="username"  class="form-control" id="InputName" placeholder="Enter Your Username"
                                           required>
                                    <?php if($errors->has('username')): ?>
                                        <span class="error form-error-msg ">
                                                <strong><?php echo e($errors->first('username')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label for="InputAmount">Password<span class="requred">*</span></label>
                                    <input type="password" name="password"  class="form-control" id="InputAmount" placeholder="Enter Your Password"
                                           required>
                                </div>
                            </div>

                            <div class="col-xl-12 col-lg-12">
                                <div class="row d-flex">
                                    <div class="col-xl-6 col-lg-6">
                                        <button type="submit" class="login-button">Sign In</button>
                                    </div>
                                    <div class="col-xl-6 col-lg-6 d-flex align-items-center">
                                        <a href="<?php echo e(route('password.request')); ?>" class="forgetting-password">Forgot Password?</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- login end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>