
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- about begin -->
    <div class="about">
        <div class="container">

            <div class="row">

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <div class="single-about">
                        <div class="heading">
                            <div class="part-icon">
                                <i class="fas fa-money-check-alt"></i>
                            </div>
                            <div class="part-text">
                                <h3>Current Balance</h3>
                            </div>
                        </div>
                        <h4 class="text-center"> <span class="count-num"><?php echo e(round(Auth::user()->balance , $basic->decimal)); ?></span>
                            <span class="count-num-text"> <?php echo e($basic->currency_sym); ?></span></h4>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <div class="single-about">
                        <div class="heading">
                            <div class="part-icon">
                                <i class="far fa-money-bill-alt"></i>
                            </div>
                            <div class="part-text">
                                <h3>Total Deposit</h3>
                            </div>
                        </div>
                        <h4 class="text-center">
                            <span class="count-num"><?php echo e(round($deposit , $basic->decimal)); ?></span>
                            <span class="count-num-text"> <?php echo e($basic->currency_sym); ?></span>
                        </h4>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <a href="<?php echo e(url('/pricing')); ?>">
                        <div class="single-about">
                            <div class="heading">
                                <div class="part-icon">
                                    <i class="fas fa-briefcase"></i>
                                </div>
                                <div class="part-text">
                                    <h3>Total Packages</h3>
                                </div>
                            </div>
                            <h4 class="text-center">
                                <span class="count-num"><?php echo e($package); ?></span>

                            </h4>
                        </div>
                    </a>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <a href="<?php echo e(url('/user/deposit')); ?>">
                        <div class="single-about">
                            <div class="heading">
                                <div class="part-icon">
                                    <i class="fas fa-credit-card"></i>
                                </div>
                                <div class="part-text">
                                    <h3>Deposit Methods</h3>
                                </div>
                            </div>
                            <h4 class="text-center">
                                <span class="count-num"><?php echo e($gateway); ?></span>
                            </h4>
                        </div>
                    </a>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <a href="<?php echo e(url('/user/my-plan')); ?>">
                        <div class="single-about">
                            <div class="heading">
                                <div class="part-icon">
                                    <i class="fas fa-shopping-cart"></i>
                                </div>
                                <div class="part-text">
                                    <h3>Purchase History</h3>
                                </div>
                            </div>
                            <h4 class="text-center">
                                <span class="count-num"><?php echo e($pur); ?></span>
                            </h4>
                        </div>
                    </a>
                </div>





                <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <div class="single-about">
                        <div class="heading">
                            <div class="part-icon">
                                <i class="fas fa-hand-holding-usd"></i>
                            </div>
                            <div class="part-text">
                                <h3><?php echo e($wallet->mining->name); ?> Balance</h3>
                            </div>
                        </div>
                        <h4 class="text-center">
                            <span class="count-num"><?php echo e($wallet->balance); ?></span>
                            <span class="count-num-text"><?php echo e($wallet->mining->coin_code); ?></span>
                        </h4>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </div>
    <!-- about end -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>