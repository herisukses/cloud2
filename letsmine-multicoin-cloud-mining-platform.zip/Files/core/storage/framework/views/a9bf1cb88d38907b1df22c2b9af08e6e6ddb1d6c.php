

<?php $__env->startSection('content'); ?>

    <?php $page_title = "404 Not Found" ?>
    <?php echo $__env->make('partials.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- about begin -->
    <div class="about">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-8">
                    <div class="section-title">
                        <h2>Sorry, Page Not Found</h2>
                        <p> <a href="<?php echo e(url('/')); ?>"><i class="fas fa-home"></i> Back To Home</a> </p>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- about end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>