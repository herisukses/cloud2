<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- banner begin-->
    <div class="banner">
        <div class="banner-content">
            <div class="container">
                <div class="row d-flex justify-content-center">
                    <div class="col-xl-6 col-lg-9 d-flex align-items-center">
                        <div class="part-text">
                            <h1><?php echo e($basic->breadcrumb_text); ?></h1>
                            <p><?php echo e($basic->breadcrumb_text2); ?></p>
                            <?php if(auth()->guard()->guest()): ?>
                            <a href="<?php echo e(url('/register')); ?>">Sign Up</a>
                            <a href="<?php echo e(url('/login')); ?>">Sign In</a>
                                <?php else: ?>
                                <a href="<?php echo e(route('home')); ?>">Dashboard</a>
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">Logout</a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                      style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="part-img">
                            <img src="<?php echo e(asset('assets/images/logo/header-vector.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- banner end -->

    <!-- counter begin-->
    <div class="counter">
        <div class="container">
            <div class="row d-flex">
                <?php
                    $cssClass = array('','two','three');
                ?>
                <?php $__currentLoopData = $howItWork; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k =>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 col-lg-4 col-md-6 d-flex align-items-center">
                    <div class="single-counter text-center">

                        <div class="part-text">
                            <h3><?php echo e($data->title); ?></h3>
                            <h4><?php echo e($data->details); ?></h4>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- counter end -->

    <!-- about begin -->
    <div class="about">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-8">
                    <div class="section-title">
                        <h2><?php echo e($basic->earn_revenues_title); ?></h2>
                        <p><?php echo e($basic->earn_revenues_sub_title); ?></p>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $earnRevenues->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earnRevenue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <?php $__currentLoopData = $earnRevenue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-6 col-lg-6 col-md-6">
                    <div class="single-about">
                        <div class="heading">
                            <div class="part-icon">
                                <img style="max-width: 50px;" src="<?php echo e(asset('assets/images/'.$data->image)); ?>" alt="new ways icon">
                            </div>
                            <div class="part-text">
                                <h3><?php echo e($data->title); ?></h3>
                            </div>
                        </div>
                        <p><?php echo $data->details; ?></p>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- about end -->

    <!-- we think global begin-->
    <div class="we-think-global newsletter" style="background-image: url(<?php echo e(asset('assets/images/logo/breadcrumb.jpg')); ?>)">
        <div class="container">
            <div class="row d-flex">
                <div class="col-xl-12 col-lg-12 col-md-12 d-flex align-items-center">
                    <div class="col-xl-12 d-flex align-items-center">
                        <div class="part-right" style="width: 100%">
                            <h3>How Much I Will Earn?</h3>
                            <form class="newsletter-form">

                                <div class="form-row">
                                    <div class="col-md-4">
                                        <select id="coin-id" style="padding: 17px; padding-right: 0px" class="pranto-select">
                                            <option value="">Select Miner</option>
                                            <?php $__currentLoopData = $miners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-4">
                                        <select class="input-field pranto-select" id="plan-id">
                                            <option value="">Select Plan</option>
                                        </select>
                                    </div>

                                    <div class="col-md-4">
                                        <input type="text" name="amo" placeholder="Quantity" class="input-field pranto-select" id="amo">
                                    </div>
                                </div>
                            </form>

                                <br>
                                <br>
                              <h5 class="result" style="color: white" id="mining-price"></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- we think global end -->

    <!-- choosing resons begin-->
    <div class="choosing-reason">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-8">
                    <div class="section-title">
                        <h2><?php echo e($basic->featured); ?></h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="single-reason">
                            <div class="part-img text-center" style="font-size: 26px;">
                                <?php echo $data->icon; ?>

                            </div>
                            <div class="part-text">
                                <h3><?php echo e($data->title); ?></h3>
                                <p><?php echo $data->details; ?></p>
                                
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- choosing resons end -->

    <!-- transaction begin-->
    <div class="transaction">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-8">
                    <div class="section-title text-center">
                        <h2>Latest<span> Transaction</span></h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="transaction-area">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#deposit" role="tab"
                                   aria-selected="true">Deposit</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#withdraw" role="tab"
                                   aria-selected="false">Withdraw</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="deposit" role="tabpanel" aria-labelledby="home-tab">

                                <table class="table text-center">
                                    <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">Trx</th>
                                        <th scope="col">Details</th>
                                        <th scope="col">Amount</th>
                                        <th scope="col">Time</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php if(count($deposit_pranto) >0): ?>
                                        <?php $__currentLoopData = $deposit_pranto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td data-label="SL"><?php echo e($data->user->name); ?></td>
                                                <td data-label="#Trx"><?php echo e(isset($data->trx) ? $data->trx : 'N/A'); ?></td>
                                                <td data-label="Details"><?php echo isset($data->gateway->name) ? $data->gateway->name : 'N/A'; ?></td>
                                                <td data-label="Amount"><?php echo isset($data->amount) ? $data->amount : 'N/A'; ?> <?php echo $basic->currency; ?></td>
                                                <td data-label="Time">
                                                    <?php echo date(' d M, Y h:s A', strtotime($data->created_at)); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5" class="td-separator">
                                                    <span class="separator"></span>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5">  Don't yet have any deposit history !!</td>
                                        </tr>
                                    <?php endif; ?>

                                    </tbody>
                                </table>

                            </div>
                            <div class="tab-pane fade" id="withdraw" role="tabpanel" aria-labelledby="profile-tab">

                                <table class="table text-center">
                                    <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">Trx</th>

                                        <th scope="col">Amount</th>
                                        <th scope="col">Time</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(count($deposit_pranto) >0): ?>
                                        <?php $__currentLoopData = $withdraw_pranto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td data-label="SL"><?php echo e($data->user->name); ?></td>
                                                <td data-label="#Trx"><?php echo e(isset($data->transaction_id) ? $data->transaction_id : 'N/A'); ?></td>
                                                <td data-label="Amount"><?php echo isset($data->amount) ? $data->amount : 'N/A'; ?> <?php echo $basic->currency; ?></td>
                                                <td data-label="Time">
                                                    <?php echo date(' d M, Y h:s A', strtotime($data->created_at)); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5" class="td-separator">
                                                    <span class="separator"></span>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5">  Don't yet have any deposit history !!</td>
                                        </tr>
                                    <?php endif; ?>


                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- transaction end -->

    <!-- payment begin-->
    <div class="payment">
        <div class="container">
            <div class="row d-flex">

                <div class="col-xl-5 co-lg-5 col-md-6">
                    <div class="part-form">
                        <img src="<?php echo e(asset('assets/images/'.$basic->reward_image)); ?>" alt="reward image">
                    </div>
                </div>

                <div class="col-xl-5 col-lg-5 col-md-6 d-flex align-items-center offset-xl-1 offset-lg-1">
                    <div class="row justify-content-center">
                        <div class="col-xl-12 col-lg-12">
                            <div class="section-title">
                                <h2><?php echo e($basic->reward_title); ?></h2>
                                <p><?php echo $basic->reward_details; ?></p>
                            </div>
                        </div>

                        <div class="col-xl-12 col-lg-12">

                            <?php $__currentLoopData = $gateway->chunk(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="part-accept">
                                <?php $__currentLoopData = $chank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-accept">
                                    <img src="<?php echo e(asset('assets/images/gateway/'.$data->id.'.jpg')); ?>" alt="">
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- payment end -->




    <!-- newsletter begin-->
    <div class="newsletter" style="background-image: url(<?php echo e(asset('assets/images/logo/footer_bg.jpg')); ?>)">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-7 col-lg-7">
                    <div class="section-title text-center">
                        <h2>Our Newslatter</h2>
                        <p>Enter Your Email To Get Update News</p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-xl-7 col-lg-7">
                    <form class="newsletter-form" action="<?php echo e(route('subscribe')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="email"  name="email" placeholder="Enter your email..." required>
                        <button type="submit">Subscribe Now</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- newsletter end -->


    <!-- inventor begin-->
    <div id="investors">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-6">
                    <div class="section-title text-center">
                        <h2>Our Team Members</h2>

                    </div>
                </div>
            </div>
            <div class="row">

                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <div class="box">
                            <div class="image">
                                <img class="img-fluid" src="<?php echo e(asset('assets/images/our-team/'.$data->image)); ?>" alt="">
                                <div class="social_icon">
                                    <ul>
                                        <li><p style="color: white;text-shadow: 2px 2px rgba(26,0,0,0.97)"><?php echo e($data->message); ?></p></li>
                                    </ul>

                                </div>
                            </div>
                            <div class="info">
                                <h5><?php echo $data->name; ?></h5>
                                <p><?php echo $data->designation; ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- inventor end -->

    <div class="blog-post">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-8">
                    <div class="section-title text-center">
                        <h2 class="extra-margin">Latest<span> Blog Posts</span></h2>
                    </div>
                </div>
            </div>

            <div class="row">

                <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="single-blog">
                        <div class="part-img">
                            <img src="<?php echo e(asset('assets/images/post/'.$data->image)); ?>" alt="">
                        </div>
                        <?php
                            $catSlug =  str_slug($data->category->name);
                            $k++;
                            $slug  = str_slug($data->title);
                        ?>
                        <div class="part-text">
                            <h3><a href="<?php echo e(url('details/'.$data->id.'/'.$slug)); ?>"><?php echo $data->title; ?></a></h3>
                            <h4>
                                <span class="admin">By Admin </span>.
                                <span class="date"><?php echo e($data->created_at->format('d F Y')); ?> </span>.
                                <a href="<?php echo e(route('cats.blog',[$data->category->id,$catSlug])); ?>">
                                    <span class="category"><?php echo e($data->category->name); ?></span></a>
                            </h4>
                            <p><?php echo str_limit($data->details, 400);; ?></p>
                            <a class="read-more" href="<?php echo e(url('details/'.$data->id.'/'.$slug)); ?>"><span><i class="fas fa-book-reader"></i></span> Read More</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
       $(document).on('change', '#coin-id', function (e) {
           e.preventDefault();
           var coinId = $('option:selected', this).val();
           $('#plan-id').html('');
           $.ajax({
              type: "post",
              url: "<?php echo e(route('get.plan')); ?>",
              data: {id: coinId},
              success: function (data) {
                  if(data.length > 0) {
                      $('#plan-id').append('<option>Select Plan</option>');
                      $.each(data ,function (index, value) {
                          $('#plan-id').append('<option value=" '+value.id+' " data-return_rate=" '+ value.return_amount +' " data-electricity_charge="'+ value.electricity_charge +'" data-coin_code=" '+ value.mining.coin_code +' "> '+ value.title +' </option>');
                      });
                  }
              },
           });
       });
       $(document).on('keyup', '#amo', function () {
           var amo = $(this).val();
           if(isNaN(amo)){
               $(this).val(0);
           }
           var rate = $('#plan-id option:selected').data('return_rate');
           var electricity_charge = $('#plan-id option:selected').data('electricity_charge');
           var coinCode = $('#plan-id option:selected').data('coin_code');
           if(isNaN(rate)){
               rate = 0;
               coinCode = '';
           }
           rate = parseFloat(rate);
           var price = (rate-electricity_charge) * amo;
           $('#mining-price').text(price + ' ' + coinCode + ' (per day)');
       });
        $(document).on('change', '#plan-id', function (e) {
            var rate = $('option:selected', this).data('return_rate');
            var coinCode = $('option:selected', this).data('coin_code');
            var electricity_charge = $('#plan-id option:selected').data('electricity_charge');
            rate = parseFloat(rate);
            var amo = $('#amo').val();
            var price = (rate-electricity_charge) * amo;
            price = price.toFixed(8);
            $('#mining-price').text(price + ' ' + coinCode + ' (per day)' );
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>