<?php if(count($popular) >0): ?>
    <div class="widget widget-popular-post">
        <h6 class="widgettitle">
            <span>Popular Posts</span>
        </h6>
        <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $slug = str_slug($data->title)
            ?>
        <div class="single-post">
            <div class="part-img">
                <img src="<?php echo e(asset('assets/images/post/'.$data->image)); ?>" alt="">
            </div>
            <div class="part-text">
                <h4><a href="<?php echo e(route('blog.details',[$data->id,$slug])); ?>"><?php echo e(str_limit($data->title,30)); ?></a></h4>
                <h5><?php echo e($data->created_at->format('d F, Y')); ?></h5>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
