
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <!-- blog post begin-->
    <div class="blog-post">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-8">
                    <div class="section-title text-center">
                        <h2 class="extra-margin">Latest<span> Blog Posts</span></h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-8 col-lg-8">
                    <div class="row">

                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-6 col-lg-6 col-md-6">
                                <div class="single-blog">
                                    <div class="part-img">
                                        <img src="<?php echo e(asset('assets/images/post/'.$post->image)); ?>" alt="">
                                    </div>
                                    <?php
                                        $k++;
                                        $slug  = str_slug($post->title);
                                    ?>


                                    <div class="part-text">
                                        <h3><a href="<?php echo e(url('details/'.$post->id.'/'.$slug)); ?>"><?php echo $post->title; ?></a></h3>
                                        <h4>
                                            <span class="admin">By Admin </span>.
                                            <span class="date"><?php echo e($post->created_at->format('d F Y')); ?>  </span>.
                                            <span class="category"><?php echo $post->title; ?> </span>
                                        </h4>
                                        <p><?php echo str_limit($post->details, 700);; ?></p>
                                        <a class="read-more" href="<?php echo e(url('details/'.$post->id.'/'.$slug)); ?>"><span><i class="fas fa-book-reader"></i></span> Read More</a>
                                    </div>
                                </div>
                            </div>
                            <?php if($k%2 == 0): ?>
                                <div class="col-md-12">
                                    <?php echo show_add(2); ?>

                                    <br>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-12">

                    <div class="sidebar">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-6">
                                <?php echo $__env->make('partials.category', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>

                            <div class="col-xl-12 col-lg-12 col-md-6">
                                <?php echo $__env->make('partials.popular-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>

                        </div>
                    </div>

                </div>
            </div>


        </div>
    </div>
    <!-- blog post end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>