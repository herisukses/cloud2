
<?php if(count($categories) >0): ?>
    <div class="widget widget_categories">
        <h6 class="widgettitle"><span>Categories</span></h6>

        <ul>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $slug = str_slug($category->name)
                ?>
                <li><a href="<?php echo e(url('cats/'.$category->id.'/'.$slug)); ?>"><?php echo $category->name; ?> <span
                                class="count">(<?php echo $category->posts()->count(); ?>

                            )</span></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>