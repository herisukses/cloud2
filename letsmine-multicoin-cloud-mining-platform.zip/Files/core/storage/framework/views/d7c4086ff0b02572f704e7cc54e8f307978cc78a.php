
<!-- page title begin-->
<div class="page-title">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-6">
                <h2><?php echo e($page_title); ?></h2>
            </div>
        </div>
    </div>
</div>
<!-- page title end -->
